// === Dependencies ===
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const QRCode = require('qrcode');
const { Telegraf, Markup } = require('telegraf');

const atlantic = require('./atlanticClient');
const { BOT_TOKEN, ADMIN_IDS } = require('./config');

if (!BOT_TOKEN) throw new Error('BOT_TOKEN belum diisi di .env');

// === Konfigurasi Fee & TTL ===
const FEE_PERCENT = 0.007;            // 0,7%
const FEE_FIXED   = 200;              // Rp200
const PAYMENT_TTL_MS = 5 * 60 * 1000; // 5 menit

// === Utils ===
function escapeHtml(s = '') {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function isAdmin(id) {
  if (!Array.isArray(ADMIN_IDS)) return false;
  return ADMIN_IDS.map(String).includes(String(id));
}

function idr(n) {
  try { return Number(n).toLocaleString('id-ID'); }
  catch { return String(n); }
}

// "17 Oktober 2025 pukul 17.57"
function fmtWIB(d = new Date()) {
  const tz = 'Asia/Jakarta';
  const day = new Intl.DateTimeFormat('id-ID', { day: '2-digit', timeZone: tz }).format(d);
  const month = new Intl.DateTimeFormat('id-ID', { month: 'long', timeZone: tz }).format(d);
  const year = new Intl.DateTimeFormat('id-ID', { year: 'numeric', timeZone: tz }).format(d);
  const hour = new Intl.DateTimeFormat('id-ID', { hour: '2-digit', hour12: false, timeZone: tz }).format(d);
  const minute = new Intl.DateTimeFormat('id-ID', { minute: '2-digit', timeZone: tz }).format(d);
  return `${day} ${month} ${year} pukul ${hour}.${minute}`;
}

// === Helpers kirim foto aman ===
// src: Buffer | {source:Buffer} | filePath | http(s) URL | long string (QR content)
async function ctxSendPhotoSafe(ctx, src, caption = '') {
  let buffer = null;

  try {
    if (Buffer.isBuffer(src)) {
      buffer = src;
    } else if (src && typeof src === 'object' && Buffer.isBuffer(src.source)) {
      buffer = src.source;
    } else if (typeof src === 'string') {
      if (!/^https?:\/\//i.test(src) && fs.existsSync(src)) {
        buffer = fs.readFileSync(src);
      } else if (/^https?:\/\//i.test(src)) {
        const res = await axios.get(src, { responseType: 'arraybuffer', timeout: 15000 });
        buffer = Buffer.from(res.data);
      } else if (src.length > 50) { // anggap QR string
        buffer = await QRCode.toBuffer(src, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
      }
    }
  } catch {
    if (!buffer && typeof src === 'string') {
      buffer = await QRCode.toBuffer(src, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
    }
  }

  if (!buffer) throw new Error('ctxSendPhotoSafe: unable to build buffer from src');

  const opts = caption ? { caption: escapeHtml(caption), parse_mode: 'HTML' } : {};
  try {
    return await ctx.replyWithPhoto({ source: buffer }, opts);
  } catch (err) {
    if (typeof src === 'string' && /^https?:\/\//i.test(src)) {
      return await ctx.replyWithPhoto(src, opts);
    }
    throw err;
  }
}

async function sendQrisPhoto(ctx, { qris_image, qris_string, caption = '' }) {
  let buf = null;

  try {
    if (qris_image && /^https?:\/\//i.test(qris_image)) {
      const res = await axios.get(qris_image, { responseType: 'arraybuffer', timeout: 15000 });
      buf = Buffer.from(res.data);
    } else if (qris_string) {
      buf = await QRCode.toBuffer(qris_string, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
    }
  } catch {
    if (qris_string) {
      buf = await QRCode.toBuffer(qris_string, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
    }
  }

  if (!buf) throw new Error('sendQrisPhoto: No QR source available');
  const opts = caption ? { caption: escapeHtml(caption), parse_mode: 'HTML' } : {};
  return ctx.replyWithPhoto({ source: buf }, opts);
}

// kirim QR + caption singkat
async function sendQrisImage(ctx, { qris_string, qris_image, invoice_id, ref, total_charge }) {
  await ctx.replyWithChatAction('upload_photo');
  const cap = `Invoice: ${escapeHtml(String(invoice_id || '').slice(0, 64))}\nRef: ${escapeHtml(ref)}\nNominal: Rp${escapeHtml(idr(total_charge))}`;
  if (qris_string) {
    const png = await QRCode.toBuffer(qris_string, { scale: 8 });
    return ctx.replyWithPhoto({ source: png }, { caption: cap, parse_mode: 'HTML' });
  }
  if (qris_image) return sendQrisPhoto(ctx, { qris_image, caption: cap });
  return ctx.reply(cap);
}

// === Data Produk ===
const productsPath = path.join(__dirname, 'products.json');
let products = [];
try {
  products = JSON.parse(fs.readFileSync(productsPath, 'utf8'));
} catch {
  products = [];
}
function saveProducts() {
  products.forEach((p) => {
    p.accounts = p.accounts || [];
    p.stock = p.accounts.filter((a) => !a.used).length;
  });
  fs.writeFileSync(productsPath, JSON.stringify(products, null, 2), 'utf8');
}

// === Bot State ===
const bot = new Telegraf(BOT_TOKEN);
const session = new Map(); // chatId -> {}
/**
 * pending:
 *   invoice_id -> {
 *     chatId, ref, reff_id, code, qty,
 *     baseTotal, serviceFee, totalCharge,
 *     note, createdAt, expiresAt, productName
 *   }
 */
const pending = new Map();

function S(chatId) {
  if (!session.has(chatId)) session.set(chatId, {});
  return session.get(chatId);
}

// === Start ===
bot.start((ctx) => {
  const kb = Markup.inlineKeyboard([[Markup.button.callback('📦 List Produk', 'LIST_PROD')]]);
  ctx.reply('Halo! Selamat datang 👋', kb);
});

// === /admin menu ===
bot.command('admin', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const text = [
    '👑 *Menu Admin*',
    '',
    '/products — Lihat ringkas produk',
    '/add_product {"code":"CODE","name":"Name","price":10000,"desc":"..."}',
    '/delete_product CODE',
    '/set_price CODE HARGA',
    '/set_desc CODE Deskripsi…',
    '/add_account CODE {"email":"..","password":"..","desc":".."}',
    '/remove_account CODE INDEX',
    '/list_accounts CODE'
  ].join('\n');
  ctx.reply(text, { parse_mode: 'Markdown' });
});

// === List produk ===
bot.action('LIST_PROD', async (ctx) => {
  await ctx.answerCbQuery();
  if (products.length === 0) return ctx.editMessageText('Belum ada produk.');
  const lines = products.map((p, i) => `${i + 1}. ${p.name} — ${p.price} (stok: ${p.stock || 0})`);
  const btns = products.map((_, i) => Markup.button.callback(String(i + 1), `SEL_${i}`));
  const rows = [];
  for (let i = 0; i < btns.length; i += 5) rows.push(btns.slice(i, i + 5));
  ctx.editMessageText('Daftar produk:\n\n' + lines.join('\n'), Markup.inlineKeyboard(rows));
});

// === Pilih produk ===
bot.action(/SEL_\d+/, async (ctx) => {
  await ctx.answerCbQuery();
  const idx = Number(ctx.match[0].split('_')[1]);
  const p = products[idx];
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  const st = S(ctx.chat.id);
  st.selected = { idx, code: p.code };

  const text = `*${p.name}*\nHarga: ${p.price}\nStok: ${p.stock || 0}\n${p.desc || ''}\n\nPilih jumlah akun:`;
  const qtyBtns = [[1, 2, 3, 4, 5].map((n) => Markup.button.callback(String(n), `QTY_${n}`))];
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(qtyBtns) });
});

// === Pilih qty ===
bot.action(/QTY_\d+/, async (ctx) => {
  await ctx.answerCbQuery();
  const qty = Number(ctx.match[0].split('_')[1]);
  const st = S(ctx.chat.id);
  if (!st.selected) return ctx.reply('Silakan pilih produk dahulu.');
  const p = products[st.selected.idx];
  if ((p.stock || 0) < qty) return ctx.editMessageText(`Stok kurang. Stok: ${p.stock || 0}`);
  st.qty = qty;
  const txt = `Konfirmasi:\nProduk: ${p.name}\nQty: ${qty}\nTotal: *${p.price * qty}*\n\nKlik untuk bayar via QRIS.`;
  const kb = Markup.inlineKeyboard([
    [Markup.button.callback('💳 Pay now via QRIS', 'PAY_NOW')],
    [Markup.button.callback('⬅️ Kembali', 'LIST_PROD')],
  ]);
  ctx.editMessageText(txt, { parse_mode: 'Markdown', ...kb });
});

// === Buat invoice & kirim QR + ringkasan ===
bot.action('PAY_NOW', async (ctx) => {
  await ctx.answerCbQuery();
  const chatId = ctx.chat.id;
  const st = S(chatId);
  if (!st?.selected || !st?.qty) return ctx.reply('Silakan pilih produk & jumlah terlebih dahulu.');
  const p = products[st.selected.idx];
  const baseTotal = p.price * st.qty;

  // Fee buyer: 0,7% + Rp200
  const serviceFee = Math.round(baseTotal * FEE_PERCENT) + FEE_FIXED;
  const totalCharge = baseTotal + serviceFee;

  const ref = `ORD_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  try {
    const inv = await atlantic.createQrisInvoice({ amount: totalCharge, ref_id: ref });
    const data = inv && (inv.data || inv) ? (inv.data || inv) : {};
    const invoice_id = data.invoice_id || data.id;
    const reff_id = data.reff_id || data.ref_id;
    const qris_image = data.qris_image || data.image_url || data.qrImage || data.qr_url;
    const qris_string = data.qris_string || data.qr_string || data.qrString || data.qr || data.qr_content;

    const now = new Date();
    const expiresAt = new Date(now.getTime() + PAYMENT_TTL_MS);

    // 1) Kirim QR
    await sendQrisImage(ctx, {
      qris_string,
      qris_image,
      invoice_id,
      ref,
      total_charge: totalCharge
    });

    // 2) Kirim ringkasan invoice sesuai format
    const pendingText = [
      '___(TRANSAKSI PENDING)___',
      '',
      `Invoice : ${invoice_id || '-'}`,
      `Reff : ${ref}`,
      `Jumlah : ${st.qty}`,
      `Nominal : Rp${idr(baseTotal)}`,
      `Fee: Rp${idr(serviceFee)}  (0,7% + 200)`,
      `Total Dibayar: Rp${idr(totalCharge)}`,
      `Note: Pembelian ${p.name} x${st.qty}`,
      `Jam/Tanggal: ${fmtWIB(now)}`,
      `Bayar sebelum: ${fmtWIB(expiresAt)}`
    ].join('\n');
    await ctx.reply(pendingText);

    if (!invoice_id) {
      await ctx.reply('Invoice dibuat, namun ID tidak terdeteksi. Pantau pembayaran manual.');
      return;
    }

    pending.set(invoice_id, {
      chatId,
      ref,
      reff_id,
      code: p.code,
      qty: st.qty,
      baseTotal,
      serviceFee,
      totalCharge,
      note: `Pembelian ${p.name} x${st.qty}`,
      createdAt: now.toISOString(),
      expiresAt: expiresAt.toISOString(),
      productName: p.name
    });

    await ctx.reply('Setelah transfer, sistem akan otomatis memproses. Batas waktu 5 menit.');
  } catch (e) {
    console.error('createQrisInvoice error:', e?.message || e);
    await ctx.reply('Gagal membuat invoice: ' + (e?.message || e));
  }
});

// === Commands Admin ===
bot.command('products', (ctx) => {
  const lines = products.map((p) => `${p.code} — ${p.name}\nHarga: ${p.price}\nStok: ${p.stock || 0}`);
  ctx.reply(lines.length ? lines.join('\n\n') : 'Belum ada produk.');
});

bot.command('add_product', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const json = ctx.message.text.split(/\s+/).slice(1).join(' ');
  if (!json) return ctx.reply('Usage: /add_product {"code":"CODE","name":"Name","price":10000,"desc":"..."}');
  try {
    const obj = JSON.parse(json);
    obj.code = String(obj.code || '').toUpperCase();
    obj.accounts = obj.accounts || [];
    products.push(obj);
    saveProducts();
    ctx.reply(`Produk ${obj.code} ditambahkan.`);
  } catch (e) {
    ctx.reply('JSON tidak valid: ' + e.message);
  }
});

bot.command('delete_product', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const code = (ctx.message.text.split(/\s+/)[1] || '').toUpperCase();
  const idx = products.findIndex((p) => p.code === code);
  if (idx === -1) return ctx.reply('Produk tidak ditemukan.');
  products.splice(idx, 1);
  saveProducts();
  ctx.reply(`Produk ${code} dihapus.`);
});

bot.command('add_account', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const parts = ctx.message.text.split(/\s+/).slice(1);
  if (parts.length < 2) return ctx.reply('Usage: /add_account <CODE> {"email":"..","password":"..","desc":".."}');
  const code = parts[0].toUpperCase();
  const json = parts.slice(1).join(' ');
  const p = products.find((x) => x.code === code);
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  try {
    const acc = JSON.parse(json);
    if (!acc.email || !acc.password) return ctx.reply('email & password wajib.');
    p.accounts = p.accounts || [];
    p.accounts.push({ ...acc, used: false });
    saveProducts();
    ctx.reply(`Akun ditambahkan. Stok ${code}: ${p.stock}`);
  } catch (e) {
    ctx.reply('JSON tidak valid: ' + e.message);
  }
});

bot.command('remove_account', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const parts = ctx.message.text.split(/\s+/).slice(1);
  if (parts.length < 2) return ctx.reply('Usage: /remove_account <CODE> <index>');
  const code = parts[0].toUpperCase();
  const idx = parseInt(parts[1], 10);
  const p = products.find((x) => x.code === code);
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  p.accounts = p.accounts || [];
  if (isNaN(idx) || !p.accounts[idx]) return ctx.reply('Index akun tidak valid.');
  p.accounts.splice(idx, 1);
  saveProducts();
  ctx.reply(`Akun dihapus. Stok ${code}: ${p.stock}`);
});

bot.command('list_accounts', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const code = (ctx.message.text.split(/\s+/)[1] || '').toUpperCase();
  const p = products.find((x) => x.code === code);
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  p.accounts = p.accounts || [];
  if (!p.accounts.length) return ctx.reply('Belum ada akun.');
  const lines = p.accounts.map(
    (a, i) => `${i}. ${a.email} | ${a.used ? 'USED' : 'idle'} | ${a.desc || ''}`
  );
  ctx.reply(lines.join('\n'));
});

bot.command('set_price', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const parts = ctx.message.text.split(/\s+/).slice(1);
  if (parts.length < 2) return ctx.reply('Usage: /set_price <CODE> <price>');
  const code = parts[0].toUpperCase();
  const price = parseInt(parts[1], 10);
  const p = products.find((x) => x.code === code);
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  if (isNaN(price)) return ctx.reply('price harus angka');
  p.price = price;
  saveProducts();
  ctx.reply(`Harga ${code} diupdate ke ${price}`);
});

bot.command('set_desc', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('Hanya admin.');
  const parts = ctx.message.text.split(/\s+/).slice(1);
  if (parts.length < 2) return ctx.reply('Usage: /set_desc <CODE> <desc...>');
  const code = parts[0].toUpperCase();
  const desc = parts.slice(1).join(' ');
  const p = products.find((x) => x.code === code);
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  p.desc = desc;
  saveProducts();
  ctx.reply(`Deskripsi ${code} diperbarui.`);
});

// === Polling status & Auto-cancel 5 menit ===
setInterval(async () => {
  const now = Date.now();
  for (const [invoice_id, payload] of pending.entries()) {
    try {
      const res = await atlantic.getInvoiceStatus({ invoice_id, reff_id: payload.reff_id });
      const status = res?.data?.status || 'PENDING';

      // Auto-cancel jika lewat TTL dan belum paid
      const exp = new Date(payload.expiresAt).getTime();
      if (now > exp && status !== 'PAID') {
        try {
          if (typeof atlantic.cancelInvoice === 'function') {
            await atlantic.cancelInvoice({ invoice_id, reff_id: payload.reff_id });
          }
        } catch {}
        await bot.telegram.sendMessage(
          payload.chatId,
          `⏰ Waktu pembayaran habis. Invoice ${invoice_id} dibatalkan.`
        );
        pending.delete(invoice_id);
        continue;
      }

      if (status === 'PAID') {
        const { chatId, ref, code, qty } = payload;
        const p = products.find((x) => x.code === code);
        if (!p) { pending.delete(invoice_id); continue; }

        p.accounts = p.accounts || [];
        const available = p.accounts.filter((a) => !a.used);
        if (available.length < qty) {
          const msg = `⚠️ PAID tapi stok kurang untuk ${code}. Dibutuhkan ${qty}, tersedia ${available.length}. Ref: ${ref}`;
          (ADMIN_IDS || []).forEach((id) => bot.telegram.sendMessage(id, msg).catch(() => {}));
          continue;
        }

        const send = available.slice(0, qty);
        send.forEach((a) => (a.used = true));
        saveProducts();

        let text = `✅ Pembayaran diterima.\nRef: ${ref}\nProduk: ${p.name}\nJumlah akun: ${qty}\n\n`;
        text += send
          .map(
            (a, i) =>
              `Akun #${i + 1}\nEmail: ${a.email}\nPassword: ${a.password}\nDeskripsi: ${a.desc || ''}`
          )
          .join('\n\n');

        await bot.telegram.sendMessage(chatId, text, { disable_web_page_preview: true });

        try {
          if (typeof atlantic.instantDeposit === 'function') {
            await atlantic.instantDeposit({ invoice_id });
          }
        } catch {}
        pending.delete(invoice_id);
      }

      if (['EXPIRED', 'CANCELLED'].includes(status)) {
        await bot.telegram.sendMessage(
          payload.chatId,
          `ℹ️ Invoice ${invoice_id} berstatus ${status}.`
        );
        pending.delete(invoice_id);
      }
    } catch {
      // abaikan cycle ini
    }
  }
}, 5000);

module.exports = bot;
