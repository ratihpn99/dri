// === Dependencies ===
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const QRCode = require('qrcode');
const { Telegraf, Markup } = require('telegraf');

const atlantic = require('./atlanticClient');
const { BOT_TOKEN, ADMIN_IDS } = require('./config');

if (!BOT_TOKEN) throw new Error('BOT_TOKEN belum diisi di .env');

// === Konfigurasi Fee & TTL ===
const FEE_PERCENT = 0.007;            // 0,7%
const FEE_FIXED   = 200;              // Rp200
const PAYMENT_TTL_MS = 5 * 60 * 1000; // 5 menit

// === Utils ===
function escapeHtml(s = '') {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function escapeMarkdown(s = '') {
  return String(s)
    .replace(/\\/g, '\\\\')
    .replace(/\*/g, '\\*')
    .replace(/_/g, '\\_')
    .replace(/\[/g, '\\[')
    .replace(/\]/g, '\\]')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)')
    .replace(/~/g, '\\~')
    .replace(/`/g, '\\`')
    .replace(/>/g, '\\>')
    .replace(/#/g, '\\#')
    .replace(/\+/g, '\\+')
    .replace(/-/g, '\\-')
    .replace(/=/g, '\\=')
    .replace(/\|/g, '\\|')
    .replace(/\{/g, '\\{')
    .replace(/\}/g, '\\}')
    .replace(/\./g, '\\.')
    .replace(/!/g, '\\!');
}

// CSV Parser for accounts
function parseCSV(csvText) {
  const lines = csvText.trim().split('\n');
  if (lines.length < 2) return [];
  
  const header = lines[0].split(',').map(h => h.trim().toLowerCase());
  const emailIdx = header.indexOf('email');
  const passwordIdx = header.indexOf('password');
  const descIdx = header.indexOf('desc');
  
  if (emailIdx === -1 || passwordIdx === -1) {
    throw new Error('CSV harus memiliki kolom "email" dan "password"');
  }
  
  const accounts = [];
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim());
    if (values.length < 2) continue;
    
    accounts.push({
      email: values[emailIdx] || '',
      password: values[passwordIdx] || '',
      desc: descIdx !== -1 ? (values[descIdx] || '') : ''
    });
  }
  
  return accounts;
}

function isAdmin(id) {
  if (!Array.isArray(ADMIN_IDS)) return false;
  return ADMIN_IDS.map(String).includes(String(id));
}

function idr(n) {
  try { return Number(n).toLocaleString('id-ID'); }
  catch { return String(n); }
}

// "17 Oktober 2025 pukul 17.57"
function fmtWIB(d = new Date()) {
  const tz = 'Asia/Jakarta';
  const day = new Intl.DateTimeFormat('id-ID', { day: '2-digit', timeZone: tz }).format(d);
  const month = new Intl.DateTimeFormat('id-ID', { month: 'long', timeZone: tz }).format(d);
  const year = new Intl.DateTimeFormat('id-ID', { year: 'numeric', timeZone: tz }).format(d);
  const hour = new Intl.DateTimeFormat('id-ID', { hour: '2-digit', hour12: false, timeZone: tz }).format(d);
  const minute = new Intl.DateTimeFormat('id-ID', { minute: '2-digit', timeZone: tz }).format(d);
  return `${day} ${month} ${year} pukul ${hour}.${minute}`;
}

// === Helpers kirim foto aman ===
// src: Buffer | {source:Buffer} | filePath | http(s) URL | long string (QR content)
async function ctxSendPhotoSafe(ctx, src, caption = '') {
  let buffer = null;

  try {
    if (Buffer.isBuffer(src)) {
      buffer = src;
    } else if (src && typeof src === 'object' && Buffer.isBuffer(src.source)) {
      buffer = src.source;
    } else if (typeof src === 'string') {
      if (!/^https?:\/\//i.test(src) && fs.existsSync(src)) {
        buffer = fs.readFileSync(src);
      } else if (/^https?:\/\//i.test(src)) {
        const res = await axios.get(src, { responseType: 'arraybuffer', timeout: 15000 });
        buffer = Buffer.from(res.data);
      } else if (src.length > 50) { // anggap QR string
        buffer = await QRCode.toBuffer(src, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
      }
    }
  } catch {
    if (!buffer && typeof src === 'string') {
      buffer = await QRCode.toBuffer(src, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
    }
  }

  if (!buffer) throw new Error('ctxSendPhotoSafe: unable to build buffer from src');

  const opts = caption ? { caption: escapeHtml(caption), parse_mode: 'HTML' } : {};
  try {
    return await ctx.replyWithPhoto({ source: buffer }, opts);
  } catch (err) {
    if (typeof src === 'string' && /^https?:\/\//i.test(src)) {
      return await ctx.replyWithPhoto(src, opts);
    }
    throw err;
  }
}

async function sendQrisPhoto(ctx, { qris_image, qris_string, caption = '' }) {
  let buf = null;

  try {
    if (qris_image && /^https?:\/\//i.test(qris_image)) {
      const res = await axios.get(qris_image, { responseType: 'arraybuffer', timeout: 15000 });
      buf = Buffer.from(res.data);
    } else if (qris_string) {
      buf = await QRCode.toBuffer(qris_string, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
    }
  } catch {
    if (qris_string) {
      buf = await QRCode.toBuffer(qris_string, { errorCorrectionLevel: 'M', type: 'png', scale: 8 });
    }
  }

  if (!buf) throw new Error('sendQrisPhoto: No QR source available');
  const opts = caption ? { caption: escapeHtml(caption), parse_mode: 'HTML' } : {};
  return ctx.replyWithPhoto({ source: buf }, opts);
}

// kirim QR + caption singkat
async function sendQrisImage(ctx, { qris_string, qris_image, invoice_id, ref, total_charge }) {
  await ctx.replyWithChatAction('upload_photo');
  // Just send QR without caption - caption will be sent separately
  if (qris_string) {
    const png = await QRCode.toBuffer(qris_string, { 
      scale: 10, 
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    });
    return ctx.replyWithPhoto({ source: png });
  }
  if (qris_image) {
    try {
      const res = await axios.get(qris_image, { responseType: 'arraybuffer', timeout: 15000 });
      const buf = Buffer.from(res.data);
      return ctx.replyWithPhoto({ source: buf });
    } catch {
      return ctx.replyWithPhoto(qris_image);
    }
  }
  return null;
}

// === Data Produk ===
const productsPath = path.join(__dirname, 'products.json');
let products = [];
try {
  products = JSON.parse(fs.readFileSync(productsPath, 'utf8'));
} catch {
  products = [];
}
function saveProducts() {
  products.forEach((p) => {
    // Update stock for main accounts
    p.accounts = p.accounts || [];
    p.stock = p.accounts.filter((a) => !a.used).length;
    
    // Update stock for variations
    if (p.variations && Array.isArray(p.variations)) {
      p.variations.forEach((v) => {
        v.accounts = v.accounts || [];
        v.stock = v.accounts.filter((a) => !a.used).length;
      });
    }
  });
  fs.writeFileSync(productsPath, JSON.stringify(products, null, 2), 'utf8');
}

// === Bot State ===
const bot = new Telegraf(BOT_TOKEN);
const session = new Map(); // chatId -> {}
/**
 * pending:
 *   invoice_id -> {
 *     chatId, ref, reff_id, code, qty,
 *     baseTotal, serviceFee, totalCharge,
 *     note, createdAt, expiresAt, productName
 *   }
 */
const pending = new Map();

// Track message IDs per invoice for auto-delete
function trackInvoiceMsg(invoice_id, msg) {
  try {
    if (!invoice_id || !msg || !msg.message_id) return;
    const rec = pending.get(invoice_id);
    if (!rec) return;
    rec.msgIds = rec.msgIds || new Set();
    rec.msgIds.add(msg.message_id);
  } catch {}
}
async function deleteInvoiceMessages(chatId, invoice_id) {
  try {
    const rec = pending.get(invoice_id);
    if (!rec || !rec.msgIds) return;
    for (const mid of rec.msgIds) {
      try { await bot.telegram.deleteMessage(chatId, mid); } catch {}
    }
    rec.msgIds.clear?.();
  } catch {}
}


function S(chatId) {
  if (!session.has(chatId)) session.set(chatId, {});
  return session.get(chatId);
}

// Safe answer callback query (ignore timeout errors)
async function safeAnswerCbQuery(ctx, text) {
  try {
    await ctx.answerCbQuery(text);
  } catch (e) {
    // Ignore "query is too old" errors
    if (!e.message?.includes('query is too old')) {
      console.error('answerCbQuery error:', e.message);
    }
  }
}

// === Keyboard Buttons (Bottom) ===
const mainKeyboard = Markup.keyboard([
  ['📦 List Produk'],
  ['📜 Riwayat Transaksi', '✨ Produk Populer'],
  ['❓ Cara Order']
]).resize();

// === Start & Menu ===
bot.start((ctx) => {
  const text = '👋 *Selamat Datang!*\n\nSilakan pilih menu dari tombol di bawah atau klik /menu';
  ctx.reply(text, { parse_mode: 'Markdown', ...mainKeyboard });
});

bot.command('menu', (ctx) => {
  const text = '🏠 *MENU UTAMA*\n\nSilakan pilih menu dari tombol di bawah:';
  ctx.reply(text, { parse_mode: 'Markdown', ...mainKeyboard });
});

function showMainMenu(ctx) {
  const menuText = '🏠 *MENU UTAMA*\n\nSilakan pilih menu dari tombol di bawah:';
  
  if (ctx.callbackQuery) {
    ctx.editMessageText(menuText, { parse_mode: 'Markdown' });
  } else {
    ctx.reply(menuText, { parse_mode: 'Markdown', ...mainKeyboard });
  }
}

// === Handle text button commands ===
bot.hears('📦 List Produk', async (ctx) => {
  if (products.length === 0) return ctx.reply('Belum ada produk.');
  const st = S(ctx.chat.id);
  st.currentPage = 1;
  const { text, keyboard } = generateProductList(1);
  ctx.reply(text, keyboard);
});

bot.hears('📜 Riwayat Transaksi', async (ctx) => {
  const chatId = ctx.chat.id;
  
  // Get user's transaction history from pending/completed
  const userTransactions = [];
  for (const [invoice_id, payload] of pending.entries()) {
    if (payload.chatId === chatId) {
      userTransactions.push({
        invoice: invoice_id,
        ref: payload.ref,
        product: payload.productName,
        amount: payload.totalCharge,
        status: 'PENDING',
        date: new Date(payload.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
      });
    }
  }
  
  let text = '📜 *RIWAYAT TRANSAKSI*\n\n';
  if (userTransactions.length === 0) {
    text += 'Belum ada transaksi.';
  } else {
    userTransactions.forEach((trx, i) => {
      text += `${i + 1}. ${trx.product}\n`;
      text += `   Invoice: ${trx.invoice}\n`;
      text += `   Ref: ${trx.ref}\n`;
      text += `   Total: Rp${idr(trx.amount)}\n`;
      text += `   Status: ${trx.status}\n`;
      text += `   Tanggal: ${trx.date}\n\n`;
    });
  }
  
  ctx.reply(text, { parse_mode: 'Markdown' });
});

bot.hears('✨ Produk Populer', async (ctx) => {
  // Get top 10 products sorted by (total_accounts - available_accounts)
  const sortedProducts = [...products]
    .map(p => ({
      ...p,
      sold: p.accounts ? p.accounts.filter(a => a.used).length : 0
    }))
    .sort((a, b) => b.sold - a.sold)
    .slice(0, 10);
  
  let text = '✨ *PRODUK POPULER*\n\n';
  if (sortedProducts.length === 0) {
    text += 'Belum ada data produk.';
  } else {
    sortedProducts.forEach((p, i) => {
      text += `${i + 1}. ${p.name}\n`;
      text += `   Harga: Rp${idr(p.price)}\n`;
      text += `   Stok: ${p.stock || 0}\n`;
      text += `   Terjual: ${p.sold}\n\n`;
    });
  }
  
  ctx.reply(text, { parse_mode: 'Markdown' });
});

bot.hears('❓ Cara Order', async (ctx) => {
  const text = `❓ *CARA ORDER*

📝 Langkah-langkah pemesanan:

1️⃣ Klik "📦 List Produk" untuk melihat produk yang tersedia

2️⃣ Pilih produk yang ingin dibeli dengan mengklik nomor produk

3️⃣ Pilih jumlah akun yang ingin dibeli (1-5)

4️⃣ Konfirmasi pembelian dan klik "💳 Bayar Sekarang"

5️⃣ Scan QR Code yang muncul dengan aplikasi e-wallet Anda

6️⃣ Setelah pembayaran berhasil, akun akan otomatis dikirim ke chat ini

⏰ Waktu pembayaran: *5 menit*
💳 Metode pembayaran: *QRIS* (semua e-wallet)

📌 Note: Pastikan membayar sesuai nominal yang tertera!`;
  
  ctx.reply(text, { parse_mode: 'Markdown' });
});

// === Menu Actions (for inline buttons) ===
bot.action('MAIN_MENU', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  showMainMenu(ctx);
});

// === /admin menu ===
bot.command('admin', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('⛔ Akses ditolak. Hanya untuk admin.');
  showAdminMenu(ctx);
});

function showAdminMenu(ctx) {
  const text = `👑 *ADMIN PANEL*

Selamat datang di panel admin!
Gunakan tombol di bawah untuk mengelola sistem.

📊 *Statistik:*
• Total Produk: ${products.length}
• Transaksi Pending: ${pending.size}`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('📦 Kelola Produk', 'ADMIN_PRODUCTS')],
    [Markup.button.callback('➕ Tambah Produk', 'ADMIN_ADD_PRODUCT')],
    [
      Markup.button.callback('💰 Bulk Harga', 'ADMIN_BULK_PRICE'),
      Markup.button.callback('📝 Bulk Desk', 'ADMIN_BULK_DESC')
    ],
    [Markup.button.callback('📋 Lihat Transaksi', 'ADMIN_TRANSACTIONS')],
    [Markup.button.callback('⚙️ Pengaturan', 'ADMIN_SETTINGS')],
    [Markup.button.callback('🔄 Refresh', 'ADMIN_REFRESH')]
  ]);

  if (ctx.callbackQuery) {
    ctx.editMessageText(text, { parse_mode: 'Markdown', ...keyboard });
  } else {
    ctx.reply(text, { parse_mode: 'Markdown', ...keyboard });
  }
}

// Admin menu handlers
bot.action('ADMIN_REFRESH', async (ctx) => {
  await safeAnswerCbQuery(ctx, 'Diperbarui!');
  showAdminMenu(ctx);
});

bot.action('ADMIN_PRODUCTS', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  showProductManagement(ctx, 1);
});

bot.action('ADMIN_TRANSACTIONS', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  
  let text = '📋 *TRANSAKSI PENDING*\n\n';
  if (pending.size === 0) {
    text += 'Tidak ada transaksi pending.';
  } else {
    let i = 1;
    for (const [invoice_id, payload] of pending.entries()) {
      text += `${i}. Invoice: ${invoice_id}\n`;
      text += `   Produk: ${payload.productName}\n`;
      text += `   Qty: ${payload.qty}\n`;
      text += `   Total: Rp${idr(payload.totalCharge)}\n`;
      text += `   User ID: ${payload.chatId}\n\n`;
      i++;
    }
  }
  
  const kb = Markup.inlineKeyboard([[Markup.button.callback('⬅️ Kembali', 'ADMIN_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action('ADMIN_SETTINGS', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  
  const text = `⚙️ *PENGATURAN SISTEM*

📊 *Konfigurasi Saat Ini:*
• Fee Persen: ${(FEE_PERCENT * 100).toFixed(1)}%
• Fee Tetap: Rp${idr(FEE_FIXED)}
• Payment TTL: ${PAYMENT_TTL_MS / 60000} menit
• Total Admin: ${ADMIN_IDS?.length || 0}

📌 *Untuk mengubah pengaturan:*
Silakan edit file .env atau config.js`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('⬅️ Kembali', 'ADMIN_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action('ADMIN_MENU', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  showAdminMenu(ctx);
});

// Bulk Price Update Handler
bot.action('ADMIN_BULK_PRICE', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.adminAction = 'BULK_PRICE';
  
  const text = `💰 *BULK UPDATE HARGA*

Update harga banyak produk sekaligus!

📦 *Format JSON:*
\`\`\`json
[
  {
    "code": "NETFLIX_PRIVATE",
    "price": 120000
  },
  {
    "code": "DISNEY_PLUS",
    "price": 35000
  },
  {
    "code": "CANVA",
    "price": 600
  }
]
\`\`\`

📌 *Catatan:*
• Gunakan \`code\` produk yang sudah ada
• Harga baru akan menimpa harga lama
• Produk yang tidak ditemukan akan dilewati

💡 *Tips:* Lihat code produk di menu Kelola Produk`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'ADMIN_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Bulk Description Update Handler
bot.action('ADMIN_BULK_DESC', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.adminAction = 'BULK_DESC';
  
  const text = `📝 *BULK UPDATE DESKRIPSI*

Update deskripsi banyak produk sekaligus!

📦 *Format JSON:*
\`\`\`json
[
  {
    "code": "NETFLIX_PRIVATE",
    "desc": "Garansi 1 bulan, Private 5 profil"
  },
  {
    "code": "DISNEY_PLUS",
    "desc": "Garansi 30 hari, Hotstar Premium"
  },
  {
    "code": "CANVA",
    "desc": "Pro lifetime, full fitur"
  }
]
\`\`\`

📌 *Catatan:*
• Gunakan \`code\` produk yang sudah ada
• Deskripsi baru akan menimpa deskripsi lama
• Produk yang tidak ditemukan akan dilewati

💡 *Tips:* Lihat code produk di menu Kelola Produk`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'ADMIN_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Product Management
const PRODUCTS_PER_ADMIN_PAGE = 10;

function showProductManagement(ctx, page = 1) {
  const totalPages = Math.ceil(products.length / PRODUCTS_PER_ADMIN_PAGE);
  const currentPage = Math.max(1, Math.min(page, totalPages));
  const startIdx = (currentPage - 1) * PRODUCTS_PER_ADMIN_PAGE;
  const endIdx = Math.min(startIdx + PRODUCTS_PER_ADMIN_PAGE, products.length);
  
  const pageProducts = products.slice(startIdx, endIdx);
  
  let text = `📦 *KELOLA PRODUK* (${currentPage}/${totalPages})\n\n`;
  
  pageProducts.forEach((p, i) => {
    const idx = startIdx + i;
    text += `${idx + 1}. *${escapeMarkdown(p.name)}*\n`;
    text += `   Code: ${escapeMarkdown(p.code)}\n`;
    text += `   Harga: Rp${idr(p.price)}\n`;
    text += `   Stok: ${p.stock || 0}\n`;
    if (p.variations) text += `   Variasi: ${p.variations.length}\n`;
    text += `\n`;
  });
  
  const buttons = [];
  const row = [];
  pageProducts.forEach((_, i) => {
    const idx = startIdx + i;
    row.push(Markup.button.callback(String(idx + 1), `ADMIN_EDIT_PROD_${idx}`));
    if (row.length === 5) {
      buttons.push([...row]);
      row.length = 0;
    }
  });
  if (row.length > 0) buttons.push(row);
  
  // Navigation
  const navBtns = [];
  if (currentPage > 1) {
    navBtns.push(Markup.button.callback('⬅️ Prev', `ADMIN_PROD_PAGE_${currentPage - 1}`));
  }
  if (currentPage < totalPages) {
    navBtns.push(Markup.button.callback('Next ➡️', `ADMIN_PROD_PAGE_${currentPage + 1}`));
  }
  if (navBtns.length > 0) buttons.push(navBtns);
  
  buttons.push([Markup.button.callback('⬅️ Kembali ke Menu', 'ADMIN_MENU')]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
}

bot.action(/ADMIN_PROD_PAGE_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const page = Number(ctx.match[1]);
  showProductManagement(ctx, page);
});

// Edit Product Menu
bot.action(/ADMIN_EDIT_PROD_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminEditingProduct = idx;
  
  let text = `✏️ *EDIT PRODUK*\n\n`;
  text += `*Nama:* ${escapeMarkdown(p.name)}\n`;
  text += `*Code:* ${escapeMarkdown(p.code)}\n`;
  text += `*Harga:* Rp${idr(p.price)}\n`;
  text += `*Stok:* ${p.stock || 0}\n`;
  text += `*Deskripsi:* ${escapeMarkdown(p.desc || '-')}\n`;
  if (p.variations) {
    text += `\n*Variasi:* ${p.variations.length}\n`;
    p.variations.forEach((v, i) => {
      text += `  ${i + 1}. ${escapeMarkdown(v.name)} - Rp${idr(v.price)} (Stok: ${v.stock || 0})\n`;
    });
  }
  text += `\n*Total Akun:* ${p.accounts?.length || 0}`;
  
  const buttons = [
    [
      Markup.button.callback('💰 Ubah Harga', `ADMIN_CHANGE_PRICE_${idx}`),
      Markup.button.callback('📝 Ubah Desk', `ADMIN_CHANGE_DESC_${idx}`)
    ],
    [
      Markup.button.callback('➕ Tambah Variasi', `ADMIN_ADD_VAR_${idx}`),
      Markup.button.callback('✏️ Edit Variasi', `ADMIN_EDIT_VAR_${idx}`)
    ],
    [
      Markup.button.callback('👤 Kelola Akun', `ADMIN_MANAGE_ACC_${idx}`),
      Markup.button.callback('➕ Tambah Akun', `ADMIN_ADD_ACC_${idx}`)
    ],
    [Markup.button.callback('🗑️ Hapus Produk', `ADMIN_DEL_PROD_${idx}`)],
    [Markup.button.callback('⬅️ Kembali', 'ADMIN_PRODUCTS')]
  ];
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

// Add Product Handler
bot.action('ADMIN_ADD_PRODUCT', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.adminAction = 'ADD_PRODUCT';
  
  const text = `➕ *TAMBAH PRODUK BARU*

Kirim data produk dalam format JSON:

\`\`\`json
{
  "code": "PRODUCT_CODE",
  "name": "Nama Produk",
  "price": 10000,
  "desc": "Deskripsi produk"
}
\`\`\`

Contoh:
\`\`\`json
{
  "code": "SPOTIFY",
  "name": "Spotify Premium",
  "price": 15000,
  "desc": "Premium 1 bulan"
}
\`\`\``;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', 'ADMIN_MENU')]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Delete Product Handler
bot.action(/ADMIN_DEL_PROD_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const text = `🗑️ *HAPUS PRODUK*

Yakin ingin menghapus produk ini?

*Nama:* ${escapeMarkdown(p.name)}
*Code:* ${escapeMarkdown(p.code)}
*Stok:* ${p.stock || 0}

⚠️ Tindakan ini tidak dapat dibatalkan!`;

  const buttons = [
    [
      Markup.button.callback('✅ Ya, Hapus', `ADMIN_CONFIRM_DEL_${idx}`),
      Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)
    ]
  ];
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_CONFIRM_DEL_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const prodName = p.name;
  products.splice(idx, 1);
  saveProducts();
  
  await ctx.reply(`✅ Produk "${prodName}" berhasil dihapus!`);
  showProductManagement(ctx, 1);
});

// Change Price Handler
bot.action(/ADMIN_CHANGE_PRICE_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'CHANGE_PRICE';
  st.adminEditingProduct = idx;
  
  const text = `💰 *UBAH HARGA*

Produk: *${escapeMarkdown(p.name)}*
Harga saat ini: *Rp${idr(p.price)}*

Kirim harga baru (hanya angka):
Contoh: 15000`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Change Description Handler
bot.action(/ADMIN_CHANGE_DESC_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'CHANGE_DESC';
  st.adminEditingProduct = idx;
  
  const text = `📝 *UBAH DESKRIPSI*

Produk: *${escapeMarkdown(p.name)}*
Deskripsi saat ini: ${escapeMarkdown(p.desc || '-')}

Kirim deskripsi baru:`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Add Variation Handler (supports single or bulk)
bot.action(/ADMIN_ADD_VAR_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'ADD_VARIATION';
  st.adminEditingProduct = idx;
  
  const text = `➕ *TAMBAH VARIASI (Single / Bulk)*

Produk: *${escapeMarkdown(p.name)}*

📌 *Format SINGLE:*
\`\`\`json
{
  "name": "30D 1pcs",
  "price": 5000
}
\`\`\`

📦 *Format BULK (Multiple):*
\`\`\`json
[
  {
    "name": "7D 1pcs",
    "price": 1500
  },
  {
    "name": "30D 1pcs",
    "price": 5000
  },
  {
    "name": "60D 1pcs",
    "price": 9000
  }
]
\`\`\`

💡 *Tips:* Gunakan array \`[ ]\` untuk menambah banyak variasi sekaligus!`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Edit Variation Handler
bot.action(/ADMIN_EDIT_VAR_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p || !p.variations || p.variations.length === 0) {
    return ctx.reply('Produk tidak memiliki variasi.');
  }
  
  let text = `✏️ *EDIT VARIASI*\n\nProduk: *${escapeMarkdown(p.name)}*\n\nPilih variasi yang ingin diedit:\n\n`;
  p.variations.forEach((v, i) => {
    text += `${i + 1}. ${escapeMarkdown(v.name)} - Rp${idr(v.price)} (Stok: ${v.stock || 0})\n`;
  });
  
  const buttons = [];
  const row = [];
  p.variations.forEach((v, i) => {
    row.push(Markup.button.callback(String(i + 1), `ADMIN_SEL_VAR_${idx}_${i}`));
    if (row.length === 5) {
      buttons.push([...row]);
      row.length = 0;
    }
  });
  if (row.length > 0) buttons.push(row);
  buttons.push([Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_SEL_VAR_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_SEL_VAR_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p.variations[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  const text = `✏️ *EDIT VARIASI*

Produk: *${escapeMarkdown(p.name)}*
Variasi: *${escapeMarkdown(v.name)}*
Harga: Rp${idr(v.price)}
Stok: ${v.stock || 0}
Total Akun: ${v.accounts?.length || 0}

Pilih aksi:`;

  const buttons = [
    [
      Markup.button.callback('💰 Ubah Harga', `ADMIN_VAR_PRICE_${prodIdx}_${varIdx}`),
      Markup.button.callback('✏️ Ubah Nama', `ADMIN_VAR_NAME_${prodIdx}_${varIdx}`)
    ],
    [
      Markup.button.callback('➕ Tambah Akun', `ADMIN_VAR_ADD_ACC_${prodIdx}_${varIdx}`),
      Markup.button.callback('👤 Kelola Akun', `ADMIN_VAR_MANAGE_ACC_${prodIdx}_${varIdx}`)
    ],
    [Markup.button.callback('🗑️ Hapus Variasi', `ADMIN_VAR_DEL_${prodIdx}_${varIdx}`)],
    [Markup.button.callback('⬅️ Kembali', `ADMIN_EDIT_VAR_${prodIdx}`)]
  ];
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

// Variation handlers
bot.action(/ADMIN_VAR_PRICE_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_PRICE_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'CHANGE_VAR_PRICE';
  st.adminEditingProduct = prodIdx;
  st.adminEditingVariation = varIdx;
  
  const text = `💰 *UBAH HARGA VARIASI*

Produk: *${escapeMarkdown(p.name)}*
Variasi: *${escapeMarkdown(v.name)}*
Harga saat ini: *Rp${idr(v.price)}*

Kirim harga baru (hanya angka):
Contoh: 15000`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_SEL_VAR_${prodIdx}_${varIdx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action(/ADMIN_VAR_NAME_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_NAME_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'CHANGE_VAR_NAME';
  st.adminEditingProduct = prodIdx;
  st.adminEditingVariation = varIdx;
  
  const text = `✏️ *UBAH NAMA VARIASI*

Produk: *${escapeMarkdown(p.name)}*
Nama saat ini: *${escapeMarkdown(v.name)}*

Kirim nama baru:
Contoh: 30D 1pcs`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_SEL_VAR_${prodIdx}_${varIdx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action(/ADMIN_VAR_ADD_ACC_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_ADD_ACC_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'ADD_VAR_ACCOUNT';
  st.adminEditingProduct = prodIdx;
  st.adminEditingVariation = varIdx;
  
  const text = `➕ *TAMBAH AKUN KE VARIASI (Single / Bulk / CSV)*

Produk: *${escapeMarkdown(p.name)}*
Variasi: *${escapeMarkdown(v.name)}*

📌 *Format SINGLE JSON:*
\`\`\`json
{
  "email": "user@example.com",
  "password": "password123",
  "desc": "Akun slot 1"
}
\`\`\`

📦 *Format BULK JSON:*
\`\`\`json
[
  {
    "email": "user1@example.com",
    "password": "pass123",
    "desc": "Slot 1"
  },
  {
    "email": "user2@example.com",
    "password": "pass456",
    "desc": "Slot 2"
  }
]
\`\`\`

📄 *Format CSV:*
\`\`\`
email,password,desc
user1@ex.com,pass123,Slot 1
user2@ex.com,pass456,Slot 2
\`\`\`

💡 *Tips:* JSON array atau CSV untuk bulk!`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_SEL_VAR_${prodIdx}_${varIdx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

bot.action(/ADMIN_VAR_MANAGE_ACC_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_MANAGE_ACC_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  let text = `👤 *KELOLA AKUN VARIASI*\n\nProduk: *${escapeMarkdown(p.name)}*\nVariasi: *${escapeMarkdown(v.name)}*\n\n`;
  
  if (!v.accounts || v.accounts.length === 0) {
    text += 'Belum ada akun.';
  } else {
    v.accounts.forEach((a, i) => {
      text += `${i + 1}. ${a.email}\n`;
      text += `   Password: ${a.password}\n`;
      text += `   Status: ${a.used ? '🔴 Used' : '🟢 Available'}\n`;
      text += `   Desc: ${a.desc || '-'}\n\n`;
    });
  }
  
  const buttons = [];
  if (v.accounts && v.accounts.length > 0) {
    buttons.push([Markup.button.callback('🗑️ Hapus Akun', `ADMIN_VAR_DEL_ACC_${prodIdx}_${varIdx}`)]);
  }
  buttons.push([Markup.button.callback('⬅️ Kembali', `ADMIN_SEL_VAR_${prodIdx}_${varIdx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_VAR_DEL_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_DEL_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v) return ctx.reply('Variasi tidak ditemukan.');
  
  const text = `🗑️ *HAPUS VARIASI*

Yakin ingin menghapus variasi ini?

Produk: *${escapeMarkdown(p.name)}*
Variasi: *${escapeMarkdown(v.name)}*
Harga: Rp${idr(v.price)}
Stok: ${v.stock || 0}

⚠️ Tindakan ini tidak dapat dibatalkan!`;

  const buttons = [
    [
      Markup.button.callback('✅ Ya, Hapus', `ADMIN_VAR_CONFIRM_DEL_${prodIdx}_${varIdx}`),
      Markup.button.callback('❌ Batal', `ADMIN_SEL_VAR_${prodIdx}_${varIdx}`)
    ]
  ];
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_VAR_CONFIRM_DEL_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_CONFIRM_DEL_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  
  if (!p || !p.variations || !p.variations[varIdx]) {
    return ctx.reply('Variasi tidak ditemukan.');
  }
  
  const varName = p.variations[varIdx].name;
  p.variations.splice(varIdx, 1);
  saveProducts();
  
  await ctx.reply(`✅ Variasi "${varName}" berhasil dihapus dari "${p.name}"!`);
  showAdminMenu(ctx);
});

bot.action(/ADMIN_VAR_DEL_ACC_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, varIdx] = ctx.match[0].match(/ADMIN_VAR_DEL_ACC_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v || !v.accounts || v.accounts.length === 0) {
    return ctx.reply('Tidak ada akun untuk dihapus.');
  }
  
  let text = `🗑️ *HAPUS AKUN DARI VARIASI*\n\nProduk: *${escapeMarkdown(p.name)}*\nVariasi: *${escapeMarkdown(v.name)}*\n\nPilih akun yang ingin dihapus:\n\n`;
  
  v.accounts.forEach((a, i) => {
    text += `${i + 1}. ${a.email} - ${a.used ? '🔴 Used' : '🟢 Available'}\n`;
  });
  
  const buttons = [];
  const row = [];
  v.accounts.forEach((a, i) => {
    row.push(Markup.button.callback(String(i + 1), `ADMIN_VAR_CONFIRM_DEL_ACC_${prodIdx}_${varIdx}_${i}`));
    if (row.length === 5) {
      buttons.push([...row]);
      row.length = 0;
    }
  });
  if (row.length > 0) buttons.push(row);
  buttons.push([Markup.button.callback('❌ Batal', `ADMIN_VAR_MANAGE_ACC_${prodIdx}_${varIdx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_VAR_CONFIRM_DEL_ACC_(\d+)_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const match = ctx.match[0].match(/ADMIN_VAR_CONFIRM_DEL_ACC_(\d+)_(\d+)_(\d+)/);
  const [_, prodIdx, varIdx, accIdx] = match.map(Number);
  const p = products[prodIdx];
  const v = p?.variations?.[varIdx];
  
  if (!v || !v.accounts || !v.accounts[accIdx]) {
    return ctx.reply('Akun tidak ditemukan.');
  }
  
  const accEmail = v.accounts[accIdx].email;
  v.accounts.splice(accIdx, 1);
  saveProducts();
  
  await ctx.reply(`✅ Akun "${accEmail}" berhasil dihapus dari variasi "${escapeMarkdown(v.name)}"!\nStok baru: ${v.stock}`);
  
  // Return to variation management
  const text = `✏️ *EDIT VARIASI*

Produk: *${escapeMarkdown(p.name)}*
Variasi: *${escapeMarkdown(v.name)}*
Harga: Rp${idr(v.price)}
Stok: ${v.stock || 0}
Total Akun: ${v.accounts?.length || 0}

Pilih aksi:`;

  const buttons = [
    [
      Markup.button.callback('💰 Ubah Harga', `ADMIN_VAR_PRICE_${prodIdx}_${varIdx}`),
      Markup.button.callback('✏️ Ubah Nama', `ADMIN_VAR_NAME_${prodIdx}_${varIdx}`)
    ],
    [
      Markup.button.callback('➕ Tambah Akun', `ADMIN_VAR_ADD_ACC_${prodIdx}_${varIdx}`),
      Markup.button.callback('👤 Kelola Akun', `ADMIN_VAR_MANAGE_ACC_${prodIdx}_${varIdx}`)
    ],
    [Markup.button.callback('🗑️ Hapus Variasi', `ADMIN_VAR_DEL_${prodIdx}_${varIdx}`)],
    [Markup.button.callback('⬅️ Kembali', `ADMIN_EDIT_VAR_${prodIdx}`)]
  ];
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

// Manage Accounts Handler
bot.action(/ADMIN_MANAGE_ACC_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  let text = `👤 *KELOLA AKUN*\n\nProduk: *${escapeMarkdown(p.name)}*\n\n`;
  
  if (!p.accounts || p.accounts.length === 0) {
    text += 'Belum ada akun.';
  } else {
    p.accounts.forEach((a, i) => {
      text += `${i + 1}. ${a.email}\n`;
      text += `   Password: ${a.password}\n`;
      text += `   Status: ${a.used ? '🔴 Used' : '🟢 Available'}\n`;
      text += `   Desc: ${a.desc || '-'}\n\n`;
    });
  }
  
  const buttons = [];
  if (p.accounts && p.accounts.length > 0) {
    buttons.push([Markup.button.callback('🗑️ Hapus Akun', `ADMIN_SELECT_DEL_ACC_${idx}`)]);
  }
  buttons.push([Markup.button.callback('⬅️ Kembali', `ADMIN_EDIT_PROD_${idx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

// Delete Account Selection Handler
bot.action(/ADMIN_SELECT_DEL_ACC_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p || !p.accounts || p.accounts.length === 0) {
    return ctx.reply('Tidak ada akun untuk dihapus.');
  }
  
  let text = `🗑️ *HAPUS AKUN*\n\nProduk: *${escapeMarkdown(p.name)}*\n\nPilih akun yang ingin dihapus:\n\n`;
  
  p.accounts.forEach((a, i) => {
    text += `${i + 1}. ${a.email} - ${a.used ? '🔴 Used' : '🟢 Available'}\n`;
  });
  
  const buttons = [];
  const row = [];
  p.accounts.forEach((a, i) => {
    row.push(Markup.button.callback(String(i + 1), `ADMIN_CONFIRM_DEL_ACC_${idx}_${i}`));
    if (row.length === 5) {
      buttons.push([...row]);
      row.length = 0;
    }
  });
  if (row.length > 0) buttons.push(row);
  buttons.push([Markup.button.callback('❌ Batal', `ADMIN_MANAGE_ACC_${idx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

bot.action(/ADMIN_CONFIRM_DEL_ACC_(\d+)_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const [_, prodIdx, accIdx] = ctx.match[0].match(/ADMIN_CONFIRM_DEL_ACC_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  
  if (!p || !p.accounts || !p.accounts[accIdx]) {
    return ctx.reply('Akun tidak ditemukan.');
  }
  
  const accEmail = p.accounts[accIdx].email;
  p.accounts.splice(accIdx, 1);
  saveProducts();
  
  await ctx.reply(`✅ Akun "${accEmail}" berhasil dihapus dari "${escapeMarkdown(p.name)}"!\nStok baru: ${p.stock}`);
  
  // Return to manage accounts page
  let text = `👤 *KELOLA AKUN*\n\nProduk: *${escapeMarkdown(p.name)}*\n\n`;
  
  if (!p.accounts || p.accounts.length === 0) {
    text += 'Belum ada akun.';
  } else {
    p.accounts.forEach((a, i) => {
      text += `${i + 1}. ${a.email}\n`;
      text += `   Password: ${a.password}\n`;
      text += `   Status: ${a.used ? '🔴 Used' : '🟢 Available'}\n`;
      text += `   Desc: ${a.desc || '-'}\n\n`;
    });
  }
  
  const buttons = [];
  if (p.accounts && p.accounts.length > 0) {
    buttons.push([Markup.button.callback('🗑️ Hapus Akun', `ADMIN_SELECT_DEL_ACC_${prodIdx}`)]);
  }
  buttons.push([Markup.button.callback('⬅️ Kembali', `ADMIN_EDIT_PROD_${prodIdx}`)]);
  
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
});

// Add Account Handler (supports single or bulk)
bot.action(/ADMIN_ADD_ACC_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[1]);
  const p = products[idx];
  
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  
  const st = S(ctx.chat.id);
  st.adminAction = 'ADD_ACCOUNT';
  st.adminEditingProduct = idx;
  
  const text = `➕ *TAMBAH AKUN (Single / Bulk / CSV)*

Produk: *${escapeMarkdown(p.name)}*

📌 *Format SINGLE JSON:*
\`\`\`json
{
  "email": "user@example.com",
  "password": "password123",
  "desc": "Akun slot 1"
}
\`\`\`

📦 *Format BULK JSON:*
\`\`\`json
[
  {
    "email": "user1@example.com",
    "password": "pass123",
    "desc": "Slot 1"
  },
  {
    "email": "user2@example.com",
    "password": "pass456",
    "desc": "Slot 2"
  }
]
\`\`\`

📄 *Format CSV (baris per baris):*
\`\`\`
email,password,desc
user1@example.com,pass123,Slot 1
user2@example.com,pass456,Slot 2
user3@example.com,pass789,Slot 3
\`\`\`

💡 *Tips:* 
• JSON: Gunakan array \`[ ]\` untuk bulk
• CSV: Header wajib, lalu data per baris`;

  const kb = Markup.inlineKeyboard([[Markup.button.callback('❌ Batal', `ADMIN_EDIT_PROD_${idx}`)]]);
  ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
});

// Handle text input for admin actions
bot.on('text', async (ctx) => {
  if (!isAdmin(ctx.from.id)) return;
  
  const st = S(ctx.chat.id);
  if (!st.adminAction) return;
  
  const action = st.adminAction;
  const prodIdx = st.adminEditingProduct;
  
  try {
    switch (action) {
      case 'ADD_PRODUCT': {
        const data = JSON.parse(ctx.message.text);
        if (!data.code || !data.name || !data.price) {
          return ctx.reply('❌ Data tidak lengkap. Harus ada code, name, dan price.');
        }
        data.code = String(data.code).toUpperCase();
        data.accounts = [];
        data.stock = 0;
        products.push(data);
        saveProducts();
        st.adminAction = null;
        await ctx.reply(`✅ Produk "${data.name}" berhasil ditambahkan!`);
        showAdminMenu(ctx);
        break;
      }
      
      case 'CHANGE_PRICE': {
        const price = parseInt(ctx.message.text, 10);
        if (isNaN(price) || price < 0) {
          return ctx.reply('❌ Harga harus berupa angka positif.');
        }
        const p = products[prodIdx];
        if (!p) return ctx.reply('Produk tidak ditemukan.');
        p.price = price;
        saveProducts();
        st.adminAction = null;
        await ctx.reply(`✅ Harga "${p.name}" diubah menjadi Rp${idr(price)}`);
        showAdminMenu(ctx);
        break;
      }
      
      case 'CHANGE_DESC': {
        const p = products[prodIdx];
        if (!p) return ctx.reply('Produk tidak ditemukan.');
        p.desc = ctx.message.text;
        saveProducts();
        st.adminAction = null;
        await ctx.reply(`✅ Deskripsi "${p.name}" berhasil diubah!`);
        showAdminMenu(ctx);
        break;
      }
      
      case 'ADD_VARIATION': {
        const data = JSON.parse(ctx.message.text);
        const p = products[prodIdx];
        if (!p) return ctx.reply('Produk tidak ditemukan.');
        p.variations = p.variations || [];
        
        // Check if bulk (array) or single (object)
        if (Array.isArray(data)) {
          // Bulk add variations
          let added = 0;
          let failed = 0;
          for (const variation of data) {
            if (!variation.name || !variation.price) {
              failed++;
              continue;
            }
            p.variations.push({
              name: variation.name,
              price: variation.price,
              accounts: [],
              stock: 0
            });
            added++;
          }
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ *Bulk Add Variasi Selesai!*\n\n📦 Total: ${data.length}\n✅ Berhasil: ${added}\n❌ Gagal: ${failed}\n\n*Produk:* ${p.name}\n*Total Variasi:* ${p.variations.length}`, { parse_mode: 'Markdown' });
        } else {
          // Single add variation
          if (!data.name || !data.price) {
            return ctx.reply('❌ Data tidak lengkap. Harus ada name dan price.');
          }
          p.variations.push({
            name: data.name,
            price: data.price,
            accounts: [],
            stock: 0
          });
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ Variasi "${data.name}" ditambahkan ke "${p.name}"!`);
        }
        showAdminMenu(ctx);
        break;
      }
      
      case 'ADD_ACCOUNT': {
        const p = products[prodIdx];
        if (!p) return ctx.reply('Produk tidak ditemukan.');
        p.accounts = p.accounts || [];
        
        let data;
        const inputText = ctx.message.text.trim();
        
        // Check if CSV format (starts with "email," header)
        if (inputText.toLowerCase().startsWith('email,')) {
          try {
            data = parseCSV(inputText);
          } catch (e) {
            return ctx.reply(`❌ Error parsing CSV: ${e.message}`);
          }
        } else {
          // Try JSON parse
          try {
            data = JSON.parse(inputText);
          } catch (e) {
            return ctx.reply('❌ Format tidak valid. Gunakan JSON atau CSV.\n\nContoh CSV:\nemail,password,desc\nuser@ex.com,pass123,Slot 1');
          }
        }
        
        // Check if bulk (array) or single (object)
        if (Array.isArray(data)) {
          // Bulk add accounts
          let added = 0;
          let failed = 0;
          for (const acc of data) {
            if (!acc.email || !acc.password) {
              failed++;
              continue;
            }
            p.accounts.push({
              email: acc.email,
              password: acc.password,
              desc: acc.desc || '',
              used: false
            });
            added++;
          }
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ *Bulk Add Selesai!*\n\n📦 Total: ${data.length}\n✅ Berhasil: ${added}\n❌ Gagal: ${failed}\n\n*Produk:* ${p.name}\n*Stok baru:* ${p.stock}`, { parse_mode: 'Markdown' });
        } else {
          // Single add account
          if (!data.email || !data.password) {
            return ctx.reply('❌ Data tidak lengkap. Harus ada email dan password.');
          }
          p.accounts.push({
            email: data.email,
            password: data.password,
            desc: data.desc || '',
            used: false
          });
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ Akun berhasil ditambahkan ke "${p.name}"!\nStok baru: ${p.stock}`);
        }
        showAdminMenu(ctx);
        break;
      }
      
      case 'CHANGE_VAR_PRICE': {
        const price = parseInt(ctx.message.text, 10);
        if (isNaN(price) || price < 0) {
          return ctx.reply('❌ Harga harus berupa angka positif.');
        }
        const p = products[prodIdx];
        const v = p?.variations?.[st.adminEditingVariation];
        if (!v) return ctx.reply('Variasi tidak ditemukan.');
        v.price = price;
        saveProducts();
        st.adminAction = null;
        await ctx.reply(`✅ Harga variasi "${v.name}" diubah menjadi Rp${idr(price)}`);
        showAdminMenu(ctx);
        break;
      }
      
      case 'CHANGE_VAR_NAME': {
        const p = products[prodIdx];
        const v = p?.variations?.[st.adminEditingVariation];
        if (!v) return ctx.reply('Variasi tidak ditemukan.');
        v.name = ctx.message.text;
        saveProducts();
        st.adminAction = null;
        await ctx.reply(`✅ Nama variasi "${p.name}" berhasil diubah menjadi "${v.name}"!`);
        showAdminMenu(ctx);
        break;
      }
      
      case 'BULK_PRICE': {
        const data = JSON.parse(ctx.message.text);
        if (!Array.isArray(data)) {
          return ctx.reply('❌ Format harus berupa array. Contoh: [{"code":"NETFLIX","price":120000}]');
        }
        
        let updated = 0;
        let notFound = 0;
        let failed = 0;
        const results = [];
        
        for (const item of data) {
          if (!item.code || !item.price) {
            failed++;
            continue;
          }
          
          const p = products.find(x => x.code === item.code.toUpperCase());
          if (!p) {
            notFound++;
            results.push(`❌ ${item.code}: Tidak ditemukan`);
            continue;
          }
          
          const oldPrice = p.price;
          p.price = item.price;
          updated++;
          results.push(`✅ ${p.name}: Rp${idr(oldPrice)} → Rp${idr(item.price)}`);
        }
        
        saveProducts();
        st.adminAction = null;
        
        let text = `💰 *BULK UPDATE HARGA SELESAI*\n\n📊 *Statistik:*\n`;
        text += `📦 Total: ${data.length}\n`;
        text += `✅ Berhasil: ${updated}\n`;
        text += `❌ Tidak ditemukan: ${notFound}\n`;
        text += `⚠️ Gagal: ${failed}\n\n`;
        text += `📋 *Detail:*\n${results.join('\n')}`;
        
        await ctx.reply(text, { parse_mode: 'Markdown' });
        showAdminMenu(ctx);
        break;
      }
      
      case 'BULK_DESC': {
        const data = JSON.parse(ctx.message.text);
        if (!Array.isArray(data)) {
          return ctx.reply('❌ Format harus berupa array. Contoh: [{"code":"NETFLIX","desc":"Garansi 1 bulan"}]');
        }
        
        let updated = 0;
        let notFound = 0;
        let failed = 0;
        const results = [];
        
        for (const item of data) {
          if (!item.code || !item.desc) {
            failed++;
            continue;
          }
          
          const p = products.find(x => x.code === item.code.toUpperCase());
          if (!p) {
            notFound++;
            results.push(`❌ ${item.code}: Tidak ditemukan`);
            continue;
          }
          
          p.desc = item.desc;
          updated++;
          results.push(`✅ ${p.name}: Deskripsi diperbarui`);
        }
        
        saveProducts();
        st.adminAction = null;
        
        let text = `📝 *BULK UPDATE DESKRIPSI SELESAI*\n\n📊 *Statistik:*\n`;
        text += `📦 Total: ${data.length}\n`;
        text += `✅ Berhasil: ${updated}\n`;
        text += `❌ Tidak ditemukan: ${notFound}\n`;
        text += `⚠️ Gagal: ${failed}\n\n`;
        text += `📋 *Detail:*\n${results.join('\n')}`;
        
        await ctx.reply(text, { parse_mode: 'Markdown' });
        showAdminMenu(ctx);
        break;
      }
      
      case 'ADD_VAR_ACCOUNT': {
        const p = products[prodIdx];
        const v = p?.variations?.[st.adminEditingVariation];
        if (!v) return ctx.reply('Variasi tidak ditemukan.');
        v.accounts = v.accounts || [];
        
        let data;
        const inputText = ctx.message.text.trim();
        
        // Check if CSV format (starts with "email," header)
        if (inputText.toLowerCase().startsWith('email,')) {
          try {
            data = parseCSV(inputText);
          } catch (e) {
            return ctx.reply(`❌ Error parsing CSV: ${e.message}`);
          }
        } else {
          // Try JSON parse
          try {
            data = JSON.parse(inputText);
          } catch (e) {
            return ctx.reply('❌ Format tidak valid. Gunakan JSON atau CSV.\n\nContoh CSV:\nemail,password,desc\nuser@ex.com,pass123,Slot 1');
          }
        }
        
        // Check if bulk (array) or single (object)
        if (Array.isArray(data)) {
          // Bulk add accounts
          let added = 0;
          let failed = 0;
          for (const acc of data) {
            if (!acc.email || !acc.password) {
              failed++;
              continue;
            }
            v.accounts.push({
              email: acc.email,
              password: acc.password,
              desc: acc.desc || '',
              used: false
            });
            added++;
          }
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ *Bulk Add Variasi Selesai!*\n\n📦 Total: ${data.length}\n✅ Berhasil: ${added}\n❌ Gagal: ${failed}\n\n*Produk:* ${p.name}\n*Variasi:* ${v.name}\n*Stok baru:* ${v.stock}`, { parse_mode: 'Markdown' });
        } else {
          // Single add account
          if (!data.email || !data.password) {
            return ctx.reply('❌ Data tidak lengkap. Harus ada email dan password.');
          }
          v.accounts.push({
            email: data.email,
            password: data.password,
            desc: data.desc || '',
            used: false
          });
          saveProducts();
          st.adminAction = null;
          await ctx.reply(`✅ Akun berhasil ditambahkan ke variasi "${v.name}"!\nStok baru: ${v.stock}`);
        }
        showAdminMenu(ctx);
        break;
      }
    }
  } catch (e) {
    ctx.reply(`❌ Error: ${e.message}\nPastikan format JSON benar.`);
  }
});

// === List produk dengan pagination ===
const PRODUCTS_PER_PAGE = 15;

function generateProductList(page = 1) {
  const totalPages = Math.ceil(products.length / PRODUCTS_PER_PAGE);
  const currentPage = Math.max(1, Math.min(page, totalPages));
  const startIdx = (currentPage - 1) * PRODUCTS_PER_PAGE;
  const endIdx = Math.min(startIdx + PRODUCTS_PER_PAGE, products.length);
  
  const pageProducts = products.slice(startIdx, endIdx);
  const lines = pageProducts.map((p, i) => 
    `[${startIdx + i + 1}] ${p.name.toUpperCase()}`
  );
  
  const header = `┌─────────────────────┐
│     LIST PRODUK     │
│    page ${currentPage} / ${totalPages}    │
└─────────────────────┘`;
  
  const text = header + '\n\n' + lines.join('\n');
  
  // Create number buttons (5 per row)
  const btns = pageProducts.map((_, i) => 
    Markup.button.callback(String(startIdx + i + 1), `SEL_${startIdx + i}`)
  );
  const rows = [];
  for (let i = 0; i < btns.length; i += 5) {
    rows.push(btns.slice(i, i + 5));
  }
  
  // Add navigation buttons
  const navBtns = [];
  if (currentPage > 1) {
    navBtns.push(Markup.button.callback('Sebelumnya', `PAGE_${currentPage - 1}`));
  }
  if (currentPage < totalPages) {
    navBtns.push(Markup.button.callback('Berikutnya', `PAGE_${currentPage + 1}`));
  }
  if (navBtns.length > 0) rows.push(navBtns);
  
  return { text, keyboard: Markup.inlineKeyboard(rows) };
}

bot.action('LIST_PROD', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  if (products.length === 0) return ctx.editMessageText('Belum ada produk.');
  const st = S(ctx.chat.id);
  st.currentPage = 1;
  const { text, keyboard } = generateProductList(1);
  ctx.editMessageText(text, keyboard);
});

// Handle pagination
bot.action(/PAGE_\d+/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const page = Number(ctx.match[0].split('_')[1]);
  const st = S(ctx.chat.id);
  st.currentPage = page;
  const { text, keyboard } = generateProductList(page);
  ctx.editMessageText(text, keyboard);
});

// === Pilih produk - Show variations or details ===
bot.action(/SEL_\d+/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const idx = Number(ctx.match[0].split('_')[1]);
  const p = products[idx];
  if (!p) return ctx.reply('Produk tidak ditemukan.');
  const st = S(ctx.chat.id);
  st.selected = { idx, code: p.code };

  // Check if product has variations
  if (p.variations && p.variations.length > 0) {
    showProductVariations(ctx, p, idx);
  } else {
    // No variations, show simple selection
    showSimpleProduct(ctx, p, idx);
  }
});

function showProductVariations(ctx, p, idx) {
  const now = new Date();
  const timeStr = now.toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  
  let text = `┌─────────────────────┐
│ *Produk:* ${escapeMarkdown(p.name)}
│ *Stok Terjual:* ${p.sold || 0}
│ *Desk:* ${escapeMarkdown(p.desc || 'Private, S&K: premiumisme.co')}
└─────────────────────┘

┌─────────────────────┐
│ *Variasi, Harga & Stok:*`;

  p.variations.forEach((v) => {
    const stock = v.accounts ? v.accounts.filter(a => !a.used).length : 0;
    text += `\n│ • ${escapeMarkdown(v.name)}: ${idr(v.price)} - Stok: ${stock}`;
  });
  
  text += `\n└─────────────────────┘

↻ Refresh at *${timeStr} WIB*`;

  const buttons = [];
  const row = [];
  p.variations.forEach((v, i) => {
    row.push(Markup.button.callback(`${v.name} - ${idr(v.price)}`, `VAR_${idx}_${i}`));
    if (row.length === 2) {
      buttons.push([...row]);
      row.length = 0;
    }
  });
  if (row.length > 0) buttons.push(row);
  
  buttons.push([Markup.button.callback('🔄 Refresh', `REFRESH_PROD_${idx}`)]);
  buttons.push([Markup.button.callback('⬅️ Back', 'BACK_TO_LIST')]);

  ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
}

function showSimpleProduct(ctx, p, idx) {
  const st = S(ctx.chat.id);
  
  // Check if stock is available
  const availableStock = p.accounts ? p.accounts.filter(a => !a.used).length : 0;
  
  if (availableStock === 0) {
    const text = `❌ *STOK HABIS*\n\nProduk: ${escapeMarkdown(p.name)}\nMaaf, produk ini sedang tidak tersedia.\n\nSilakan pilih produk lain.`;
    const kb = Markup.inlineKeyboard([[Markup.button.callback('⬅️ Kembali ke List', 'BACK_TO_LIST')]]);
    return ctx.editMessageText(text, { parse_mode: 'Markdown', ...kb });
  }
  
  st.qty = 1;
  st.paymentMethod = 'QRIS';
  showOrderConfirmation(ctx, p, null, 1);
}

// Handle variation selection
bot.action(/VAR_(\d+)_(\d+)/, async (ctx) => {
  try { await ctx.answerCbQuery(); } catch (e) { /* ignore timeout */ }
  const [_, prodIdx, varIdx] = ctx.match[0].match(/VAR_(\d+)_(\d+)/).map(Number);
  const p = products[prodIdx];
  const variation = p.variations[varIdx];
  
  if (!variation) return ctx.reply('Variasi tidak ditemukan.');
  
  // Check if variation has stock
  const availableStock = variation.accounts ? variation.accounts.filter(a => !a.used).length : 0;
  
  if (availableStock === 0) {
    const text = `❌ *STOK HABIS*\n\nProduk: ${escapeMarkdown(p.name)}\nVariasi: ${escapeMarkdown(variation.name)}\nMaaf, variasi ini sedang tidak tersedia.\n\nSilakan pilih variasi lain.`;
    await ctx.reply(text, { parse_mode: 'Markdown' });
    return;
  }
  
  const st = S(ctx.chat.id);
  st.selected = { idx: prodIdx, code: p.code, varIdx, variation };
  st.qty = 1;
  st.paymentMethod = 'QRIS'; // default
  
  showOrderConfirmation(ctx, p, variation, 1);
});

// Refresh product info
bot.action(/REFRESH_PROD_(\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx, 'Diperbarui!');
  const idx = Number(ctx.match[0].split('_')[2]);
  const p = products[idx];
  if (!p) return;
  
  if (p.variations && p.variations.length > 0) {
    showProductVariations(ctx, p, idx);
  }
});

// Order confirmation with quantity adjustment
function showOrderConfirmation(ctx, product, variation, qty) {
  const st = S(ctx.chat.id);
  const now = new Date();
  const timeStr = now.toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  
  const price = variation ? variation.price : product.price;
  const varName = variation ? variation.name : 'Standard';
  const stock = variation ? 
    (variation.accounts ? variation.accounts.filter(a => !a.used).length : 0) :
    (product.stock || 0);
  
  const totalPrice = price * qty;
  
  let text = `╔═══════════════════════╗
║  KONFIRMASI PESANAN 🛒
╚═══════════════════════╝

┌───────────────────────┐
│ • Produk: ${escapeMarkdown(product.name)}
│ • Variasi: ${escapeMarkdown(varName)}
│ • Harga Satuan: Rp. ${idr(price)}
│ • Stok Tersedia: ${stock}
├───────────────────────┤
│ • Jumlah Pesanan: x${qty}
│ • Total Pembayaran: Rp. ${idr(totalPrice)}
└───────────────────────┘`;

  // Add warning if stock is low or qty equals stock
  if (qty === stock) {
    text += `\n\n⚠️ *Anda memesan semua stok yang tersedia!*`;
  } else if (stock <= 5) {
    text += `\n\n⚠️ *Stok terbatas: ${stock} tersisa*`;
  }
  
  text += `\n\n💡 *Atur jumlah pesanan dengan tombol +/- di bawah*\n\n↻ Refresh at *${timeStr} WIB*`;

  const buttons = [];
  
  // First row: -1 and +1 (only show +1 if not at max stock)
  const row1 = [Markup.button.callback('➖ 1', 'QTY_ADJ_-1')];
  if (qty < stock) {
    row1.push(Markup.button.callback('➕ 1', 'QTY_ADJ_+1'));
  }
  buttons.push(row1);
  
  // Second row: -5 and +5 (only show +5 if stock allows)
  const row2 = [Markup.button.callback('➖ 5', 'QTY_ADJ_-5')];
  if (qty + 5 <= stock) {
    row2.push(Markup.button.callback('➕ 5', 'QTY_ADJ_+5'));
  }
  buttons.push(row2);
  
  buttons.push([Markup.button.callback('💳 BAYAR DENGAN QRIS', 'PAY_QRIS')]);
  buttons.push([Markup.button.callback('🔄 Refresh', 'REFRESH_ORDER')]);
  buttons.push([Markup.button.callback('⬅️ Kembali', `SEL_${st.selected.idx}`)]);

  if (ctx.callbackQuery) {
    ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
  } else {
    ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
  }
}

// Quantity adjustment handlers
bot.action(/QTY_ADJ_([+-]\d+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const adjustment = Number(ctx.match[1]);
  const st = S(ctx.chat.id);
  
  if (!st.selected) return ctx.reply('Silakan pilih produk terlebih dahulu.');
  
  const p = products[st.selected.idx];
  const variation = st.selected.variation;
  
  // Calculate new quantity
  const newQty = Math.max(1, (st.qty || 1) + adjustment);
  
  // Check stock availability
  const availableStock = variation ? 
    (variation.accounts ? variation.accounts.filter(a => !a.used).length : 0) :
    (p.stock || 0);
  
  if (newQty > availableStock) {
    await ctx.answerCbQuery(`⚠️ Stok tidak cukup! Tersedia: ${availableStock}`, { show_alert: true });
    return;
  }
  
  st.qty = newQty;
  showOrderConfirmation(ctx, p, variation, st.qty);
});

// Payment with QRIS
bot.action('PAY_QRIS', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  st.paymentMethod = 'QRIS';
  
  if (!st.selected) return ctx.reply('Silakan pilih produk terlebih dahulu.');
  
  // Proceed to payment
  await processPayment(ctx);
});

bot.action('REFRESH_ORDER', async (ctx) => {
  await safeAnswerCbQuery(ctx, 'Diperbarui!');
  const st = S(ctx.chat.id);
  
  if (!st.selected) return ctx.reply('Silakan pilih produk terlebih dahulu.');
  const p = products[st.selected.idx];
  const variation = st.selected.variation;
  
  showOrderConfirmation(ctx, p, variation, st.qty || 1);
});

// Handle back to list
bot.action('BACK_TO_LIST', async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const st = S(ctx.chat.id);
  const page = st.currentPage || 1;
  const { text, keyboard } = generateProductList(page);
  ctx.editMessageText(text, keyboard);
});

// === Process Payment (with variations support) ===
async function processPayment(ctx) {
  const chatId = ctx.chat.id;
  const st = S(chatId);
  
  if (!st?.selected || !st?.qty) {
    return ctx.reply('Silakan pilih produk & jumlah terlebih dahulu.');
  }

  const p = products[st.selected.idx];
  const variation = st.selected.variation;
  const qty = st.qty;
  
  // CRITICAL: Check stock availability before creating invoice
  let availableStock;
  let accountsSource;
  
  if (variation && p.variations && p.variations[st.selected.varIdx]) {
    accountsSource = p.variations[st.selected.varIdx];
    accountsSource.accounts = accountsSource.accounts || [];
    availableStock = accountsSource.accounts.filter(a => !a.used).length;
  } else {
    accountsSource = p;
    p.accounts = p.accounts || [];
    availableStock = p.accounts.filter(a => !a.used).length;
  }
  
  if (qty > availableStock) {
    return ctx.reply(`❌ *STOK TIDAK CUKUP!*\n\nProduk: ${escapeMarkdown(p.name)}\nDiminta: ${qty}\nTersedia: ${availableStock}\n\nSilakan kurangi jumlah pesanan.`, { parse_mode: 'Markdown' });
  }
  
  // Determine price and product details
  const baseTotal = variation ? (variation.price * qty) : (p.price * qty);
  const serviceFee = Math.round(baseTotal * FEE_PERCENT) + FEE_FIXED;
  const totalCharge = baseTotal + serviceFee;
  
  const productName = variation ? `${p.name} - ${variation.name}` : p.name;
  const ref = `ORD_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  try {
    const inv = await atlantic.createQrisInvoice({ amount: totalCharge, ref_id: ref });
    const data = inv && (inv.data || inv) ? (inv.data || inv) : {};

    const invoice_id = data.invoice_id || data.id;
    const reff_id = data.reff_id || data.ref_id;
    const qris_image = data.qris_image || data.image_url || data.qrImage || data.qr_url;
    const qris_string = data.qris_string || data.qr_string || data.qrString || data.qr || data.qr_content;

    const now = new Date();
    const expiresAt = new Date(now.getTime() + PAYMENT_TTL_MS);

    if (!invoice_id) {
      await ctx.reply('Invoice dibuat, namun ID tidak terdeteksi. Pantau pembayaran manual.');
      return;
    }

    // Store invoice record FIRST before sending messages
    pending.set(invoice_id, {
      msgIds: new Set(),
      chatId,
      ref,
      reff_id,
      code: p.code,
      qty,
      baseTotal,
      serviceFee,
      totalCharge,
      note: `Pembelian ${productName} x${qty}`,
      createdAt: now.toISOString(),
      expiresAt: expiresAt.toISOString(),
      productName,
      variation: variation || null,
      varIdx: st.selected.varIdx
    });

    // 1) Kirim QR dan track message
    const qrMsg = await sendQrisImage(ctx, {
      qris_string,
      qris_image,
      invoice_id,
      ref,
      total_charge: totalCharge
    });
    trackInvoiceMsg(invoice_id, qrMsg);

    // 2) Generate transaction ID in format similar to image
    const dateStr = now.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' }).replace(/\//g, '');
    const transactionId = `VS-${dateStr}-${ref.split('_')[2].toUpperCase()}`;

    // 3) Kirim konfirmasi dengan format yang lebih menarik
    const varName = variation ? variation.name : 'Standard';
    const confirmText = `╔═══════════════════════╗
║  PESANAN TERKONFIRMASI ✅
╚═══════════════════════╝

┌───────────────────────┐
│ • Produk: ${escapeMarkdown(productName)}
│ • Variasi: ${escapeMarkdown(varName)}
│ • Harga Satuan: Rp. ${idr(baseTotal / qty)}
│ • ID Transaksi:
│   ${transactionId}
├───────────────────────┤
│ • Jumlah Pesanan: x${qty}
│ • Total Pembayaran: Rp. ${idr(totalCharge)}
└───────────────────────┘

💳 *Pembayaran kadaluwarsa dalam 5 menit.*
⚡ Silakan scan QRIS untuk menyelesaikan pembayaran!

⏰ Pembayaran dibuat: ${fmtWIB(now)}
⌛ Kadaluwarsa pada: ${fmtWIB(expiresAt)}`;

    const cancelButton = Markup.inlineKeyboard([
      [Markup.button.callback('❌ Batalkan Order', `CANCEL_ORDER_${invoice_id}`)]
    ]);

    const pendMsg = await ctx.reply(confirmText, { parse_mode: 'Markdown', ...cancelButton });
    trackInvoiceMsg(invoice_id, pendMsg);
  } catch (e) {
    console.error('createQrisInvoice error:', e?.message || e);
    await ctx.reply('Gagal membuat invoice: ' + (e?.message || e));
  }
}


// === Handle Cancel Order Button ===
bot.action(/CANCEL_ORDER_(.+)/, async (ctx) => {
  await safeAnswerCbQuery(ctx);
  const invoice_id = ctx.match[1];
  const payload = pending.get(invoice_id);
  
  if (!payload) {
    return ctx.editMessageText('❌ Invoice tidak ditemukan atau sudah diproses.');
  }
  
  if (payload.chatId !== ctx.chat.id) {
    return ctx.answerCbQuery('⛔ Ini bukan pesanan Anda!', { show_alert: true });
  }
  
  try {
    // Try to cancel the invoice via API
    if (typeof atlantic.cancelInvoice === 'function') {
      await atlantic.cancelInvoice({ invoice_id, reff_id: payload.reff_id });
    }
  } catch (e) {
    console.log('Cancel invoice error:', e?.message || e);
  }
  
  // Delete all invoice messages
  await deleteInvoiceMessages(payload.chatId, invoice_id);
  
  // Remove from pending
  pending.delete(invoice_id);
  
  // Send cancellation confirmation
  await ctx.reply(`✅ *Pesanan Dibatalkan*\n\nInvoice: ${invoice_id}\nProduk: ${escapeMarkdown(payload.productName)}\nTotal: Rp. ${idr(payload.totalCharge)}\n\nPesanan Anda telah dibatalkan.`, { parse_mode: 'Markdown' });
});

// === Polling status & Auto-cancel 5 menit ===
setInterval(async () => {
  const now = Date.now();
  for (const [invoice_id, payload] of pending.entries()) {
    try {
      const res = await atlantic.getInvoiceStatus({ invoice_id, reff_id: payload.reff_id });
      const status = res?.data?.status || 'PENDING';

      // Auto-cancel jika lewat TTL dan belum paid
      const exp = new Date(payload.expiresAt).getTime();
      if (now > exp && status !== 'PAID') {
        try {
          if (typeof atlantic.cancelInvoice === 'function') {
            await atlantic.cancelInvoice({ invoice_id, reff_id: payload.reff_id });
          }
        } catch {}
        await deleteInvoiceMessages(payload.chatId, invoice_id);
        await bot.telegram.sendMessage(
          payload.chatId,
          `⏰ Waktu pembayaran habis. Invoice ${invoice_id} dibatalkan.`
        );
        pending.delete(invoice_id);
        continue;
      }

      if (status === 'PAID') {
        const { chatId, ref, code, qty, variation, varIdx } = payload;
        const p = products.find((x) => x.code === code);
        if (!p) { pending.delete(invoice_id); continue; }

        // Get accounts from variation or main product
        let accountsSource;
        let productDisplayName;
        
        if (variation && p.variations && p.variations[varIdx]) {
          accountsSource = p.variations[varIdx];
          productDisplayName = `${p.name} - ${variation.name}`;
        } else {
          accountsSource = p;
          productDisplayName = p.name;
        }

        accountsSource.accounts = accountsSource.accounts || [];
        const available = accountsSource.accounts.filter((a) => !a.used);
        
        if (available.length < qty) {
          const msg = `⚠️ PAID tapi stok kurang untuk ${productDisplayName}. Dibutuhkan ${qty}, tersedia ${available.length}. Ref: ${ref}`;
          (ADMIN_IDS || []).forEach((id) => bot.telegram.sendMessage(id, msg).catch(() => {}));
          continue;
        }

        const send = available.slice(0, qty);
        send.forEach((a) => (a.used = true));
        
        // Update stock count
        if (variation && p.variations && p.variations[varIdx]) {
          p.variations[varIdx].stock = p.variations[varIdx].accounts.filter(a => !a.used).length;
        }
        saveProducts();

        // Delete QR and pending messages
        await deleteInvoiceMessages(chatId, invoice_id);

        // Create beautiful success message
        let text = `╔═══════════════════════╗
║  PEMBAYARAN BERHASIL ✅
╚═══════════════════════╝

┌───────────────────────┐
│ • Ref: ${ref}
│ • Produk: ${escapeMarkdown(productDisplayName)}
│ • Jumlah Akun: ${qty}
│ • Total: Rp. ${idr(payload.totalCharge)}
└───────────────────────┘

🎉 *Terima kasih atas pembelian Anda!*

📦 *Detail Akun Anda:*
━━━━━━━━━━━━━━━━━━━━━\n\n`;

        text += send
          .map(
            (a, i) =>
              `🔐 *Akun #${i + 1}*\n📧 Email: \`${a.email}\`\n🔑 Password: \`${a.password}\`\n📝 Deskripsi: ${a.desc || '-'}`
          )
          .join('\n\n━━━━━━━━━━━━━━━━━━━━━\n\n');

        text += `\n\n━━━━━━━━━━━━━━━━━━━━━\n\n⚠️ *Penting:*\n• Simpan data akun dengan aman\n• Jangan bagikan ke orang lain\n• Hubungi admin jika ada masalah\n\n✨ Terima kasih telah berbelanja!`;

        await bot.telegram.sendMessage(chatId, text, { 
          parse_mode: 'Markdown',
          disable_web_page_preview: true 
        });

        try {
          if (typeof atlantic.instantDeposit === 'function') {
            await atlantic.instantDeposit({ invoice_id });
          }
        } catch {}
        pending.delete(invoice_id);
      }

      if (['EXPIRED', 'CANCELLED'].includes(status)) {
        await deleteInvoiceMessages(payload.chatId, invoice_id);
        await bot.telegram.sendMessage(
          payload.chatId,
          `ℹ️ Invoice ${invoice_id} berstatus ${status}.`
        );
        pending.delete(invoice_id);
      }
    } catch {
      // abaikan cycle ini
    }
  }
}, 5000);

module.exports = bot;
