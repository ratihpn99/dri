# Telegram Auto Order — Safe QR (no URL) + Admin CRUD

## Quick Start
```bash
unzip telegram-autoorder-atlantich2h-crud-safeqr.zip
cd telegram-autoorder-atlantich2h-crud-safeqr
cp .env.example .env
# isi BOT_TOKEN, ADMIN_IDS, ATLANTIC_API_KEY (dan pastikan IP server di-whitelist di Atlantic)
npm i
npm run start
```

## Admin Commands
- `/admin` — help
- `/products` — list produk + stok
- `/addproduct code|name|price`
- `/delproduct code`
- `/setprice code price`
- `/addstock code` (kirim banyak baris stok, akhiri `DONE`)
- `/liststock code`
- `/delstock code n`
- `/send code @username` — kirim 1 stok manual ke user

## Catatan QR
Bot **tidak pernah** mengirim URL gambar ke Telegram. QR dibuat dari `qris_string` jadi PNG lokal.
Jika hanya tersedia URL QR dari provider, bot mengunduhnya dulu (via axios) lalu mengirim **buffer**.
