const axios = require('axios');
const { ATLANTIC } = require('./config');

const api = axios.create({ baseURL: ATLANTIC.BASE_URL, timeout: 20000 });

function toForm(data){
  const p = new URLSearchParams();
  Object.entries(data).forEach(([k, v]) => v !== undefined && p.append(k, String(v)));
  return p;
}

exports.createQrisInvoice = async ({ amount, ref_id }) => {
  const payload = toForm({
    api_key: ATLANTIC.API_KEY,
    apikey: ATLANTIC.API_KEY, // fallback
    reff_id: ref_id,
    nominal: amount,
    type: 'ewallet',
    metode: 'qris'
  });
  const { data } = await api.post('/deposit/create', payload, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  });
  const ok = Boolean(data?.status === true || data?.code === 200);
  const inv = data?.data || {};
  return {
    success: ok,
    message: data?.message || data?.msg || (ok ? 'OK' : 'FAILED'),
    data: {
      invoice_id: inv.id || null,
      qris_string: inv.qr_string || null,
      qris_image_url: inv.qr_image || null,
      expire_at: inv.expired_at || null
    }
  };
};

exports.getInvoiceStatus = async (invoice_id) => {
  const payload = toForm({ api_key: ATLANTIC.API_KEY, apikey: ATLANTIC.API_KEY, id: invoice_id });
  const { data } = await api.post('/deposit/status', payload, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  });
  const st = (data?.data?.status || '').toUpperCase();
  let status = 'PENDING';
  if (['SUCCESS', 'PAID'].includes(st)) status = 'PAID';
  if (['EXPIRED', 'TIMEOUT'].includes(st)) status = 'EXPIRED';
  if (['CANCELLED', 'CANCELED'].includes(st)) status = 'CANCELLED';
  return { success: true, message: 'OK', data: { status } };
};
