const { v4: uuidv4 } = require('uuid');
exports.makeRef = (p='ORD') => `${p}_${Date.now()}_${uuidv4().slice(0,8)}`;
exports.isAdmin = (id, admins) => admins.includes(Number(id));
