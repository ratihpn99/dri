const { Telegraf, Markup } = require('telegraf');
const QRCode = require('qrcode');
const axios = require('axios');
const { BOT_TOKEN, ADMINS } = require('./config');
const atlantic = require('./atlanticClient');
const { makeRef, isAdmin } = require('./utils');
const store = require('./store');

if (!BOT_TOKEN) throw new Error('BOT_TOKEN belum diisi di .env');
const bot = new Telegraf(BOT_TOKEN);
const session = new Map();
const invoiceMap = new Map();

function S(id){ if(!session.has(id)) session.set(id,{}); return session.get(id); }
async function getProductsArr(){ const d = await store.read(); return Object.values(d.products||{}); }
async function getProduct(code){ const d = await store.read(); return (d.products||{})[code]; }
async function upsertProduct(p){ const d = await store.read(); if(!d.products)d.products={}; if(!d.products[p.code]) d.products[p.code]={...p,stock:[]}; else { const old=d.products[p.code]; d.products[p.code]={...old,...p,stock:old.stock||[]}; } await store.write(d); }
async function deleteProduct(code){ const d = await store.read(); if(d.products && d.products[code]){ delete d.products[code]; await store.write(d); return true; } return false; }
async function addStock(code, items){ const d = await store.read(); if(!d.products||!d.products[code]) throw new Error('Produk tidak ditemukan'); d.products[code].stock=d.products[code].stock||[]; d.products[code].stock.push(...items); await store.write(d); return d.products[code].stock.length; }
async function popStock(code, n=1){ const d = await store.read(); if(!d.products||!d.products[code]) throw new Error('Produk tidak ditemukan'); d.products[code].stock=d.products[code].stock||[]; const taken=d.products[code].stock.splice(0,n); await store.write(d); return taken; }
async function listStock(code){ const d=await store.read(); if(!d.products||!d.products[code]) throw new Error('Produk tidak ditemukan'); const arr=d.products[code].stock||[]; return { total: arr.length, preview: arr.slice(0,3) }; }

bot.start(async ctx => {
  await ctx.reply('Selamat datang di Auto Order Bot — stok dikelola admin, kirim akun via Telegram.');
  const prods = await getProductsArr();
  if (!prods.length) return ctx.reply('Belum ada produk.');
  const rows = prods.map(p => [Markup.button.callback(`• ${p.name} — Rp ${p.price}`, `BUY_${p.code}`)]);
  await ctx.reply('Pilih produk:', Markup.inlineKeyboard(rows, { columns: 1 }));
});

bot.action(/BUY_(.+)/, async ctx => {
  await ctx.answerCbQuery();
  const code = ctx.match[1];
  const prod = await getProduct(code);
  if (!prod) return ctx.reply('Produk tidak ditemukan.');
  const st = S(ctx.chat.id);
  st.productCode = code;
  st.step = 'ASK_TARGET';
  await ctx.reply(`*${prod.name}*\nHarga: Rp ${prod.price}\n${prod.desc||''}\n\nKetik target (opsional).`, { parse_mode: 'Markdown' });
});

bot.on('text', async ctx => {
  const st = S(ctx.chat.id);
  if (st.step === 'ASK_TARGET' && st.productCode) {
    const prod = await getProduct(st.productCode);
    const amount = prod.price;
    const ref_id = makeRef('INV');
    await ctx.reply('⏳ Membuat invoice (opsional QRIS)...');
    try {
      const resp = await atlantic.createQrisInvoice({ amount, ref_id });
      if (!resp?.success) {
        await ctx.reply(`⚠️ Gagal buat QRIS: ${resp?.message || 'Unknown error'}`);
        const [item] = await popStock(st.productCode, 1);
        if (!item) return ctx.reply('❌ Stok habis.');
        return ctx.reply(`✅ Order sukses (manual).\n\n${item}`);
      }
      const inv = resp.data || {};
      // === SAFE QR SENDING ===
      if (inv.qris_string) {
        const png = await QRCode.toBuffer(inv.qris_string, { type: 'png', width: 720 });
        await ctx.replyWithPhoto({ source: png }, { caption: `Invoice: ${inv.invoice_id}\nRp ${amount}\nStatus: PENDING` });
      } else if (inv.qris_image_url) {
        try {
          const imgResp = await axios.get(inv.qris_image_url, { responseType: 'arraybuffer', headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 15000 });
          const buf = Buffer.from(imgResp.data);
          await ctx.replyWithPhoto({ source: buf }, { caption: `Invoice: ${inv.invoice_id}\nRp ${amount}\nStatus: PENDING` });
        } catch {
          await ctx.reply('⚠️ QR tidak dapat diambil dari URL provider. Silakan scan QR manual di aplikasi e-wallet.');
        }
      } else {
        await ctx.reply('Invoice dibuat. Silakan scan QR di aplikasi e-wallet Anda.');
      }
      invoiceMap.set(inv.invoice_id, { chatId: ctx.chat.id, productCode: st.productCode });
      st.step = null;
    } catch (e) {
      await ctx.reply(`❌ Error QRIS: ${e.message}`);
      const [item] = await popStock(st.productCode, 1);
      if (!item) return ctx.reply('❌ Stok habis.');
      await ctx.reply(`✅ Order sukses (manual).\n\n${item}`);
      st.step = null;
    }
  }
});

setInterval(async () => {
  for (const [invoice_id, meta] of invoiceMap.entries()) {
    try {
      const st = await atlantic.getInvoiceStatus(invoice_id);
      const status = st?.data?.status || 'PENDING';
      if (status === 'PAID') {
        invoiceMap.delete(invoice_id);
        const [item] = await popStock(meta.productCode, 1);
        if (!item) return bot.telegram.sendMessage(meta.chatId, '⚠️ Pembayaran diterima tapi stok kosong.');
        await bot.telegram.sendMessage(meta.chatId, `✅ Pembayaran diterima.\n\n${item}`);
      }
      if (['EXPIRED','CANCELLED'].includes(status)) invoiceMap.delete(invoice_id);
    } catch {}
  }
}, 15000);

// ===== Admin Commands =====
bot.command('admin', async ctx => {
  if (!isAdmin(ctx.from.id, ADMINS)) return;
  await ctx.reply(`*Admin Commands:*
/products - list produk
/addproduct code|name|price
/delproduct code
/setprice code price
/addstock code  -> kirim banyak baris stok, akhiri dengan *DONE*
/liststock code
/delstock code n
/send code @username  -> kirim 1 stok manual`, { parse_mode: 'Markdown' });
});

bot.command('products', async ctx => {
  if (!isAdmin(ctx.from.id, ADMINS)) return;
  const arr = await getProductsArr();
  if (!arr.length) return ctx.reply('Belum ada produk.');
  const msg = arr.map(p => `• ${p.code} — ${p.name} (Rp ${p.price}) [stok: ${p.stock?.length||0}]`).join('\n');
  await ctx.reply(msg);
});

bot.command('addproduct', async ctx => {
  if (!isAdmin(ctx.from.id, ADMINS)) return;
  const raw = ctx.message.text.split(' ').slice(1).join(' ');
  const [code, name, priceStr] = (raw||'').split('|').map(s => (s||'').trim());
  if (!code || !name || !priceStr) return ctx.reply('Format: /addproduct code|name|price');
  await upsertProduct({ code, name, price: Number(priceStr) });
  await ctx.reply(`✅ Produk ${code} ditambahkan/diupdate.`);
});

bot.command('delproduct', async ctx => {
  if (!isAdmin(ctx.from.id, ADMINS)) return;
  const code = ctx.message.text.split(' ')[1];
  if (!code) return ctx.reply('Format: /delproduct code');
  const ok = await deleteProduct(code);
  await ctx.reply(ok ? `✅ Produk ${code} dihapus.` : 'Produk tidak ditemukan.');
});

bot.command('setprice', async ctx => {
  if (!isAdmin(ctx.from.id, ADMINS)) return;
  const [_, code, priceStr] = ctx.message.text.split(' ');
  if (!code || !priceStr) return ctx.reply('Format: /setprice code price');
  const prod = await getProduct(code);
  if (!prod) return ctx.reply('Produk tidak ditemukan.');
  prod.price = Number(priceStr);
  await upsertProduct(prod);
  await ctx.reply(`✅ Harga ${code} diupdate menjadi Rp ${prod.price}.`);
});

bot.command('addstock', async ctx => {
  if (!isAdmin(ctx.from.id, ADMINS)) return;
  const code = ctx.message.text.split(' ')[1];
  if (!code) return ctx.reply('Format: /addstock code (kemudian kirim daftar stok, akhiri dg DONE)');
  const st = S(ctx.from.id);
  st.addStockFor = code;
  await ctx.reply(`Kirim stok untuk *${code}*.
Kirim beberapa baris (satu stok per baris).
Ketik *DONE* bila selesai.`, { parse_mode: 'Markdown' });
});

bot.command('liststock', async ctx => {
  if (!isAdmin(ctx.from.id, ADMINS)) return;
  const code = ctx.message.text.split(' ')[1];
  if (!code) return ctx.reply('Format: /liststock code');
  try {
    const { total, preview } = await listStock(code);
    const prev = preview.length ? ('\nContoh:\n' + preview.map((x,i)=>`${i+1}. ${x}`).join('\n')) : '';
    await ctx.reply(`Stok ${code}: ${total} item${prev}`);
  } catch (e) {
    await ctx.reply(`Error: ${e.message}`);
  }
});

bot.command('delstock', async ctx => {
  if (!isAdmin(ctx.from.id, ADMINS)) return;
  const [_, code, nStr] = ctx.message.text.split(' ');
  const n = Number(nStr||'1');
  if (!code) return ctx.reply('Format: /delstock code n');
  try {
    const removed = await (async()=>{ const d=await store.read(); const arr=d.products?.[code]?.stock||[]; const r=arr.splice(0,n); d.products[code].stock=arr; await store.write(d); return r.length; })();
    await ctx.reply(`✅ Hapus ${removed} stok dari ${code}.`);
  } catch (e) {
    await ctx.reply(`Error: ${e.message}`);
  }
});

bot.command('send', async ctx => {
  if (!isAdmin(ctx.from.id, ADMINS)) return;
  const [_, code, username] = ctx.message.text.split(' ');
  if (!code || !username) return ctx.reply('Format: /send code @username');
  try {
    const [item] = await popStock(code, 1);
    if (!item) return ctx.reply('Stok habis.');
    const user = await ctx.telegram.getChat(username);
    await ctx.telegram.sendMessage(user.id, `🎁 *Produk dari admin:*\n${item}`, { parse_mode: 'Markdown' });
    await ctx.reply(`✅ Dikirim ke ${username}`);
  } catch (e) {
    await ctx.reply(`Error kirim: ${e.message}`);
  }
});

module.exports = bot;
