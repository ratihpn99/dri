const fs = require('fs');
const path = require('path');
const FILE = path.join(__dirname, 'store.json');

if (!fs.existsSync(FILE)) {
  fs.writeFileSync(FILE, JSON.stringify({ products: {} }, null, 2));
}

exports.read = async () => JSON.parse(fs.readFileSync(FILE, 'utf8'));
exports.write = async (data) => fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
