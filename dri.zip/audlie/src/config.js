require('dotenv').config();

module.exports = {
  BOT_TOKEN: process.env.BOT_TOKEN,
  ADMINS: (process.env.ADMIN_IDS || '').split(',').map(x => Number(x.trim())).filter(Boolean),
  ATLANTIC: {
    BASE_URL: process.env.ATLANTIC_BASE_URL || 'https://atlantich2h.com/api',
    API_KEY: process.env.ATLANTIC_API_KEY || ''
  }
};
